#include <ros.h>
#include <std_msgs/Float64.h>
#include <Servo.h>

ros::NodeHandle nh;
Servo servo1, servo2;

void servo1_callback(const std_msgs::Float64& cmd)
{
    int angle = cmd.data * 180.0 / 3.14;  
    servo1.write(angle);
}

void servo2_callback(const std_msgs::Float64& cmd)
{
    int angle = cmd.data * 180.0 / 3.14; 
    servo2.write(angle);
}

ros::Subscriber<std_msgs::Float64> joint1_sub("joint1_position_controller/command", servo1_callback);
ros::Subscriber<std_msgs::Float64> joint2_sub("joint2_position_controller/command", servo2_callback);

void setup()
{
    nh.initNode();
    nh.subscribe(joint1_sub);
    nh.subscribe(joint2_sub);

    servo1.attach(9);  
    servo2.attach(10); 
}

void loop()
{
    nh.spinOnce();
    delay(10);
}
