#!/usr/bin/env python3

import rospy 
import sys
import numpy
import math

from moveit_commander import RobotCommander, PlanningSceneInterface, MoveGroupCommander, roscpp_initialize
from moveit_msgs.msg import DisplayTrajectory, ExecuteTrajectoryGoal
from geometry_msgs.msg import Pose


class MyRobot :
    def __init__(self, group):
        roscpp_initialize(sys.argv)
        rospy.init_node("panda_arm_test_move", anonymous=True)
        
        robot = RobotCommander()
        scene = PlanningSceneInterface()

        group_name = group
        move_group = MoveGroupCommander(group_name)

        display_trajectory_publisher = rospy.Publisher("/move_group/display_planned_path", DisplayTrajectory, queue_size=20)

        planning_frame = move_group.get_planning_frame()
        print(f"=========== Planning frame: {planning_frame}")

        eef_link = move_group.get_end_effector_link()
        print(f"=========== End effector link: {eef_link}")

        group_names = robot.get_group_names()
        print(f"=========== Available Planning Groups: {group_names}")

        current_state = robot.get_current_state()
        print(f"=========== Printing robot state : {current_state}")
        print("")

        self.robot = robot
        self.scene = scene
        self.group = group_name 
        self.move_group = move_group
        self.display_trajectory_publisher = display_trajectory_publisher
        self.planning_frame = planning_frame
        self.eef_link = eef_link
        self.group_names = group_names

    def display_trajectory(self, plan):
        display_trajectory = DisplayTrajectory()
        display_trajectory.trajectory_start = self.robot.get_current_state()
        display_trajectory.trajectory,append(plan)

        self.display_trajectory_publisher.publish(display_trajectory)

    def execute_plan(self, pose):
        print(f"Going to position {pose}")
        self.move_group.set_named_target(pose)
        success, plan, _, _ = self.move_group.plan()
        self.move_group.execute(plan, wait=True)
    
    # def set_pose(self, pose):
    #     print(f"Going to position {pose}")

    #     self.move_group.set_named_target(pose)
    #     success, plan, _, _ = self.move_group.plan()

    #     goal = ExecuteTrajectoryGoal()
    #     goal.trajectory = plan

    def joint_goal(self):
        joint_goal = self.move_group.get_current_joint_values()
        joint_goal[0] = 0
        joint_goal[1] = -math.tau / 8
        joint_goal[2] = 0
        joint_goal[3] = -math.tau / 4
        joint_goal[4] = 0
        joint_goal[5] = math.tau / 6
        joint_goal[6] = 0

        self.move_group.go(joint_goal, wait=True)
        self.move_group.stop()

    def pose_goal(self):
        pose_goal = Pose()
        pose_goal.orientation.w = 1.0
        pose_goal.position.x = 0.4
        pose_goal.position.y = 0.1
        pose_goal.position.z = 0.4

        self.move_group.set_pose_target(pose_goal)
        self.move_group.go(wait=True)
        self.move_group.stop()

        self.move_group.clear_pose_target()

    # cartesian
    
    def set_pose(self, pose):
        print(f"Going to position {pose}")

        self.move_group.set_named_target(pose)
        self.move_group.go(wait=True)
        self.move_group.stop()


def main():
    group = "panda_arm"
    robot = MyRobot(group)

    while not rospy.is_shutdown():

        # robot.set_pose("ready")
        # rospy.sleep(2)

        # robot.set_pose("extended")
        # rospy.sleep(2)

        robot.execute_plan("Home")
        rospy.sleep(2)

        robot.execute_plan("grap")
        rospy.sleep(2)

        # robot.execute_plan("grap2")
        # rospy.sleep(2)

        robot.joint_goal()
        rospy.sleep(2)

        robot.pose_goal()
        rospy.sleep(2)


if __name__ == "__main__":
    main()