import rospy
import sys
from moveit_commander import RobotCommander, PlanningSceneInterface, MoveGroupCommander, roscpp_initialize, roscpp_shutdown
import tf
import tf.transformations as transformations
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from moveit_msgs.msg import Grasp, PlaceLocation, DisplayTrajectory
from geometry_msgs.msg import PoseStamped

TAU = 2 * 3.14159265359

class pick_and_place:
    def __init__ (self, group):
        roscpp_initialize(sys.argv)
        rospy.init_node("panda_arm_test_move", anonymous=True)
        
        robot = RobotCommander()
        scene = PlanningSceneInterface()

        group_name = group
        move_group = MoveGroupCommander(group_name)

        display_trajectory_publisher = rospy.Publisher("/move_group/display_planned_path", DisplayTrajectory, queue_size=20)  

        planning_frame = move_group.get_planning_frame()
        print(f"=========== Planning frame: {planning_frame}")

        eef_link = move_group.get_end_effector_link()
        print(f"=========== End effector link: {eef_link}")

        group_names = robot.get_group_names()
        print(f"=========== Available Planning Groups: {group_names}")

        current_state = robot.get_current_state()
        print(f"=========== Printing robot state : {current_state}")
        print("")

        self.robot = robot
        self.scene = scene
        self.group = group_name 
        self.move_group = move_group
        self.display_trajectory_publisher = display_trajectory_publisher
        self.planning_frame = planning_frame
        self.eef_link = eef_link
        self.group_names = group_names

    def open_gripper(self, posture):
        posture.joint_names = ["gripper_right_joint"]
        posture.points = []
        point = JointTrajectoryPoint()
        point.positions = [0]
        point.time_from_start = rospy.Duration(0.5)
        posture.points = [point]

    def close_gripper(self, posture):
        posture.joint_names = ["gripper_right_joint"]
        posture.points = []
        point = JointTrajectoryPoint()
        point.positions = [0.05]
        point.time_from_start = rospy.Duration(0.5)
        posture.points = [point]

    def pick(self):
        grasps = [Grasp()]
        grasps[0].grasp_pose.header.frame_id = "panda_link0" #base_frame
        
        quaternion = transformations.quaternion_from_euler(TAU/4, -TAU/4, 0)
        grasps[0].grasp_pose.pose.orientation.x = quaternion[0]
        grasps[0].grasp_pose.pose.orientation.y = quaternion[1]
        grasps[0].grasp_pose.pose.orientation.z = quaternion[2]
        grasps[0].grasp_pose.pose.orientation.w = quaternion[3]
        grasps[0].grasp_pose.pose.position.x = 1.0
        grasps[0].grasp_pose.pose.position.y = 0.085
        grasps[0].grasp_pose.pose.position.z = 0.5
        
        grasps[0].pre_grasp_approach.direction.header.frame_id = "panda_link0" #base_frame
        grasps[0].pre_grasp_approach.direction.vector.y = -1.0
        grasps[0].pre_grasp_approach.min_distance = 0.095
        grasps[0].pre_grasp_approach.desired_distance = 0.115
        
        grasps[0].post_grasp_retreat.direction.header.frame_id = "panda_link0" #base_frame
        grasps[0].post_grasp_retreat.direction.vector.z = 1.0
        grasps[0].post_grasp_retreat.min_distance = 0.1
        grasps[0].post_grasp_retreat.desired_distance = 0.25
        
        self.open_gripper(grasps[0].pre_grasp_posture)
        self.close_gripper(grasps[0].grasp_posture)
        
        self.move_group.set_support_surface_name("table1")
        self.move_group.pick("object", grasps)

    def place(self):
        place_location = [PlaceLocation()]
        place_location[0].place_pose.header.frame_id = "panda_link0" #base_frame
        
        quaternion = transformations.quaternion_from_euler(0, 0, TAU/4)
        place_location[0].place_pose.pose.orientation.x = quaternion[0]
        place_location[0].place_pose.pose.orientation.y = quaternion[1]
        place_location[0].place_pose.pose.orientation.z = quaternion[2]
        place_location[0].place_pose.pose.orientation.w = quaternion[3]
        
        place_location[0].place_pose.pose.position.x = 0
        place_location[0].place_pose.pose.position.y = 1.0
        place_location[0].place_pose.pose.position.z = 0.5
        
        place_location[0].pre_place_approach.direction.header.frame_id = "panda_link0" #base_frame
        place_location[0].pre_place_approach.direction.vector.z = -1.0
        place_location[0].pre_place_approach.min_distance = 0.095
        place_location[0].pre_place_approach.desired_distance = 0.115
        
        place_location[0].post_place_retreat.direction.header.frame_id = "panda_link0" #base_frame
        place_location[0].post_place_retreat.direction.vector.x = -1.0
        place_location[0].post_place_retreat.min_distance = 0.1
        place_location[0].post_place_retreat.desired_distance = 0.25
        
        self.open_gripper(place_location[0].post_place_posture)
        self.move_group.set_support_surface_name("table2")
        self.move_group.place("object", place_location)

    def add_box(self, header, box):
        print(f"adding {box}")

        box_pose = PoseStamped()
        box_pose.header.frame_id = header
        box_pose.pose.orientation.w = 1.0
        box_pose.pose.position.z = 0.11
        self.box_name = box

        self.scene.add_box(self.box_name, box_pose, size=(0.075, 0.075, 0.075))

def main():
    move_group = "panda_arm"
    robot = pick_and_place(move_group)

    robot.pick()
    rospy.sleep(1)

    robot.place()
    rospy.sleep(1)

    moveit_commander.roscpp_shutdown()

if __name__ == "__main__":
    main()