#include <ros/ros.h>
#include <hardware_interface/joint_state_interface.h>
#include <hardware_interface/joint_command_interface.h>
#include <hardware_interface/robot_hw.h> 
#include <controller_manager/controller_manager.h>

class TortaHardwareInterface : public hardware_interface::RobotHW
{
public:
    TortaHardwareInterface()
    {
        // Register joint states
        hardware_interface::JointStateHandle state_handle_1("J1", &pos[0], &vel[0], &eff[0]);
        joint_state_interface.registerHandle(state_handle_1);

        hardware_interface::JointStateHandle state_handle_2("J2", &pos[1], &vel[1], &eff[1]);
        joint_state_interface.registerHandle(state_handle_2);

        registerInterface(&joint_state_interface);

        // Register joint position control
        hardware_interface::JointHandle control_handle_1(joint_state_interface.getHandle("J1"), &cmd[0]);
        joint_position_interface.registerHandle(control_handle_1);

        hardware_interface::JointHandle control_handle_2(joint_state_interface.getHandle("J2"), &cmd[1]);
        joint_position_interface.registerHandle(control_handle_2);

        registerInterface(&joint_position_interface);
    }

    void update()
    {
        for (int i = 0; i < 2; i++)
        {
            pos[i] = cmd[i];
        }
    }

    hardware_interface::JointStateInterface joint_state_interface;
    hardware_interface::PositionJointInterface joint_position_interface;

    double cmd[2] = {0.0, 0.0};
    double pos[2] = {0.0, 0.0};
    double vel[2] = {0.0, 0.0};
    double eff[2] = {0.0, 0.0};

};


int main(int argc, char** argv)
{
    ros::init(argc, argv, "torta_hardware_interface_node");
    ros::NodeHandle nh;
    
    TortaHardwareInterface robot;
    controller_manager::ControllerManager cm(&robot, nh);
    
    ros::Rate rate(50); 
    while (ros::ok())
    {
        robot.update();
        cm.update(ros::Time::now(), ros::Duration(0.02));
        ros::spinOnce();
        rate.sleep();
    }
    return 0;
}