#!/usr/bin/env python3

import rospy
from torta_class import MyArm
from geometry_msgs.msg import Pose
from std_msgs.msg import Float32MultiArray

group = "torta_arm"
robot = MyArm(group)

def pose_callback(msg):
    x, y, z, pitch = msg.data
    rospy.loginfo("get pose ?")
    robot.pose_goal(x, y, z, pitch)


rospy.Subscriber("/target_pose", Float32MultiArray, pose_callback)

def main():
    rospy.spin()


if __name__ == "__main__":
    main()