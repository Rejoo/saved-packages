#!/usr/bin/env python3

import rospy 
import sys
import numpy
import math
import tf.transformations

from moveit_commander import RobotCommander, PlanningSceneInterface, roscpp_initialize, MoveGroupCommander
from moveit_msgs.msg import DisplayTrajectory, ExecuteTrajectoryGoal
from geometry_msgs.msg import Pose
from std_msgs.msg import Float32MultiArray


class MyArm :
    def __init__(self, group):
        roscpp_initialize(sys.argv)
        rospy.init_node("torta_arm_move", anonymous=True)
        rospy.Subscriber("/target_pose", Float32MultiArray, self.pose_callback)

        robot = RobotCommander()
        scene = PlanningSceneInterface()

        group_name = group
        move_group = MoveGroupCommander(group_name)

        display_trajectory_publisher = rospy.Publisher("/move_group/display_planned_path", DisplayTrajectory, queue_size=20)

        planning_frame = move_group.get_planning_frame()
        print(f"=========== Planning frame: {planning_frame}")

        eef_link = move_group.get_end_effector_link()
        print(f"=========== End effector link: {eef_link}")

        group_names = robot.get_group_names()
        print(f"=========== Available Planning Groups: {group_names}")

        current_state = robot.get_current_state()
        print(f"=========== Printing robot state : {current_state}")
        print("")

        self.robot = robot
        self.scene = scene
        self.group = group_name 
        self.move_group = move_group
        self.planning_frame = planning_frame
        self.display_trajectory_publisher = display_trajectory_publisher
        self.eef_link = eef_link
        self.group_names = group_names

    def display_trajectory(self, plan):
        display_trajectory = DisplayTrajectory()
        display_trajectory.trajectory_start = self.robot.get_current_state()
        display_trajectory.trajectory,append(plan)

        self.display_trajectory_publisher.publish(display_trajectory)

    def execute_plan(self, pose):
        print(f"Going to position {pose}")
        self.move_group.set_named_target(pose)
        success, plan, _, _ = self.move_group.plan()
        self.move_group.execute(plan, wait=True)

    def pose_callback(self, msg):
        x, y, z, pitch = msg.data
        rospy.loginfo("git  ?")
        self.pose_goal(x, y, z, pitch)

    def pose_goal(self, x, y, z, pitch):

        pose_goal = Pose()
        quaternion = tf.transformations.quaternion_from_euler(0, pitch, 0)
        pose_goal.orientation.x = quaternion[0]
        pose_goal.orientation.y = quaternion[1]
        pose_goal.orientation.z = quaternion[2]
        pose_goal.orientation.w = quaternion[3]
        pose_goal.position.x = x
        pose_goal.position.y = y
        pose_goal.position.z = z
        self.move_group.set_pose_target(pose_goal)
        rospy.loginfo(self.move_group.get_pose_target())
        self.move_group.go(wait=True)
        self.move_group.stop()
        rospy.loginfo("reached ?")
        
        self.move_group.clear_pose_targets() 

    
    def set_pose(self, pose):
        print(f"Going to position {pose}")

        self.move_group.set_named_target(pose)
        self.move_group.go(wait=True)
        self.move_group.stop()

if __name__ == "__main__":
    group = "torta_arm"
    MyArm(group)

    rospy.spin()