#!/usr/bin/env python3

import rospy 
import sys
import numpy
import math

from moveit_commander import RobotCommander, PlanningSceneInterface, MoveGroupCommander, roscpp_initialize
from moveit_msgs.msg import DisplayTrajectory, ExecuteTrajectoryGoal
from std_msgs.msg import Float32MultiArray
from geometry_msgs.msg import Pose, PoseStamped
from tf.transformations import quaternion_from_euler


class MyArm :
    def __init__(self, group):
        roscpp_initialize(sys.argv)
        rospy.init_node("torta_arm_move", anonymous=True)
        
        robot = RobotCommander()
        scene = PlanningSceneInterface()

        group_name = group
        move_group = MoveGroupCommander(group_name)

        display_trajectory_publisher = rospy.Publisher("/move_group/display_planned_path", DisplayTrajectory, queue_size=20)

        planning_frame = move_group.get_planning_frame()
        print(f"=========== Planning frame: {planning_frame}")

        eef_link = move_group.get_end_effector_link()
        print(f"=========== End effector link: {eef_link}")

        group_names = robot.get_group_names()
        print(f"=========== Available Planning Groups: {group_names}")

        current_state = robot.get_current_state()
        print(f"=========== Printing robot state : {current_state}")
        print("")

        self.robot = robot
        self.scene = scene
        self.group = group_name 
        self.move_group = move_group
        self.display_trajectory_publisher = display_trajectory_publisher
        self.planning_frame = planning_frame
        self.eef_link = eef_link
        self.group_names = group_names

    def display_trajectory(self, plan):
        display_trajectory = DisplayTrajectory()
        display_trajectory.trajectory_start = self.robot.get_current_state()
        display_trajectory.trajectory,append(plan)

        self.display_trajectory_publisher.publish(display_trajectory)

    def execute_plan(self, pose):
        print(f"Going to position {pose}")
        self.move_group.set_named_target(pose)
        success, plan, _, _ = self.move_group.plan()
        self.move_group.execute(plan, wait=True)
    
    # def set_pose(self, pose):
    #     print(f"Going to position {pose}")

    #     self.move_group.set_named_target(pose)
    #     success, plan, _, _ = self.move_group.plan()

    #     goal = ExecuteTrajectoryGoal()
    #     goal.trajectory = plan

    def joint_goal(self):
        joint_goal = self.move_group.get_current_joint_values()
        joint_goal[0] = 0
        joint_goal[1] = -math.tau / 8
        joint_goal[2] = 0
        joint_goal[3] = -math.tau / 4
        joint_goal[4] = 0
        joint_goal[5] = math.tau / 6
        joint_goal[6] = 0

        self.move_group.go(joint_goal, wait=True)
        self.move_group.stop()

    # def pose_goal(self, x,y,z,pitch):
    #     # self.move_group.set_planning_pipeline_id("ompl")
    #     # self.move_group.set_goal_tolerance(0.01)  # Adjust if too strict


    #     # actual_pose = self.move_group.get_current_pose()
    #     # pose_goal.header = actual_pose.header
    #     # pose_goal.header.stamp = actual_pose.header.stamp
    #     # pose_goal.header.frame_id = self.planning_frame 

    #     pose_goal = PoseStamped()
    #     pose_goal.header.frame_id = "world"  # Adjust to your planning frame if needed
    #     pose_goal.header.stamp = rospy.Time.now()
    #     quaternion = quaternion_from_euler(0, pitch, 0)
    #     pose_goal.pose.orientation.x = quaternion[0]
    #     pose_goal.pose.orientation.y = quaternion[1]
    #     pose_goal.pose.orientation.z = quaternion[2]
    #     pose_goal.pose.orientation.w = quaternion[3]
    #     pose_goal.pose.position.x = x
    #     pose_goal.pose.position.y = y
    #     pose_goal.pose.position.z = z

    #     self.move_group.set_pose_target(pose_goal)
    #     self.move_group.clear_path_constraints()
    #     self.move_group.set_goal_tolerance(0.5)

    #     self.move_group.go(pose_goal, wait=True)
    #     self.move_group.stop()

    #     self.move_group.clear_pose_targets()

    # cartesian
    def list_to_pose_stamped(self, pose, target_frame):
        pose_msg = PoseStamped()
        pose_msg.pose = pose  # Directly assign Pose to PoseStamped
        pose_msg.header.frame_id = target_frame
        pose_msg.header.stamp = rospy.Time.now()
        return pose_msg

    def pose_goal(self, x, y, z, pitch):
        """Set a pose goal and move the robot using Pose (not PoseStamped)."""
        self.move_group.clear_pose_targets()
        # Create a Pose message
        pose_goal = Pose()

        # Convert Euler angles to quaternion
        quaternion = quaternion_from_euler(0, pitch, 0)
        pose_goal.orientation.x = quaternion[0]
        pose_goal.orientation.y = quaternion[1]
        pose_goal.orientation.z = quaternion[2]
        pose_goal.orientation.w = quaternion[3]

        # Set position
        pose_goal.position.x = x
        pose_goal.position.y = y
        pose_goal.position.z = z

        self.move_group.set_goal_position_tolerance(0.01)
        self.move_group.set_goal_orientation_tolerance(0.01)
        self.move_group.allow_replanning(True)
        self.move_group.set_planner_id("RRTConnectkConfigDefault")
        self.move_group.set_start_state_to_current_state()

        self.move_group.set_planning_time(10)  # Increase planning time
        self.move_group.set_num_planning_attempts(5)  # Allow multiple attempts


        poseStamed_goal = self.list_to_pose_stamped(pose_goal,"world")
        # Call go() directly with Pose
        self.move_group.set_pose_target(poseStamed_goal) 
        self.move_group.clear_path_constraints()
        success = self.move_group.go(pose_goal, wait=True)

        if not success:
            rospy.logerr("Motion planning failed!")

        # Stop the robot and clear targets
        self.move_group.stop()
        self.move_group.clear_pose_targets()

    # def pose_goal(self, x, y, z, pitch):
    #     from geometry_msgs.msg import Pose
    #     from tf.transformations import quaternion_from_euler
    #     import rospy

    #     # Create a Pose message
    #     pose_goal = Pose()
    #     quaternion = quaternion_from_euler(0, pitch, 0)
    #     pose_goal.orientation.x = quaternion[0]
    #     pose_goal.orientation.y = quaternion[1]
    #     pose_goal.orientation.z = quaternion[2]
    #     pose_goal.orientation.w = quaternion[3]
    #     pose_goal.position.x = x
    #     pose_goal.position.y = y
    #     pose_goal.position.z = z


    #     current_pose = self.move_group.get_current_pose().pose
    #     rospy.loginfo(f"Current Pose: {current_pose}")
    #     rospy.loginfo(f"Target Pose: {pose_goal}")
    #     self.move_group.set_goal_tolerance(0.5)

        # Ensure MoveIt! treats this as a pose goal
        # self.move_group.set_pose_target(pose_goal)  
        #   # Remove any existing constraints
        # self.move_group.set_planning_time(10)  # Give more time for planning

        # # Plan first before executing
        # plan = self.move_group.plan()
        
        # if plan[0]:  # If a valid plan is found
        #     self.move_group.execute(plan[1], wait=True)
        # else:
        #     rospy.logerr("Motion planning failed. No valid plan found!")

        # self.move_group.stop()
        # self.move_group.clear_pose_targets()

    
    def set_pose(self, pose):
        print(f"Going to position {pose}")

        self.move_group.set_named_target(pose)
        self.move_group.go(wait=True)
        self.move_group.stop()


def main():
    group = "torta_arm"
    robot = MyArm(group)

    # while not rospy.is_shutdown():

    #     robot.set_pose("grip")
    #     rospy.sleep(10)

        # robot.set_pose("extended")
        # rospy.sleep(2)

        # robot.execute_plan("Home")
        # rospy.sleep(2)

        # robot.execute_plan("grap")
        # rospy.sleep(2)

        # robot.execute_plan("grap2")
        # rospy.sleep(2)

        # robot.joint_goal()
        # rospy.sleep(2)

        # robot.pose_goal()
        # rospy.sleep(2)


if __name__ == "__main__":
    main()