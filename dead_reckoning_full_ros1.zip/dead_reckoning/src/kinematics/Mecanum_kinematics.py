#!/usr/bin/env python3

import numpy as np
from kinematics.Kinematics import Kinematics  

class KinematicsMecanum(Kinematics):
    def __init__(self, Lx, Ly, wheel_radius=0.04, rate=20):
        super().__init__(wheel_radius, rate)
        self.Lx = Lx
        self.Ly = Ly
    
    def mecanum_inverse(self, Vx, Vy, W):
        angular_inverse = self.Lx + self.Ly
        first_array_inverse = np.array([[1, -1, -angular_inverse],
                                        [1,  1,  angular_inverse], 
                                        [1,  1, -angular_inverse],
                                        [1, -1,  angular_inverse]])
        input_array_inverse = np.array([[Vx], [Vy], [W]]) 
        return self.output_array_inverse(first_array_inverse, input_array_inverse, self.R)
    
    def mecanum_forward(self, w1, w2, w3, w4):
        angular_forward = self.Lx + self.Ly
        first_array_forward = np.array([[ 1,  1,  1,  1],
                                        [-1,  1,  1, -1], 
                                        [-1 / angular_forward, 1 / angular_forward, -1 / angular_forward, 1 / angular_forward]])
        input_array_forward = np.array([[w1], [w2], [w3], [w4]])    
        output_array = np.matmul((self.R/4)*first_array_forward,input_array_forward)
        return output_array    
    def wheel_velocities(self, Vx, Vy, W):
        return self.mecanum_inverse(Vx, Vy, W)
