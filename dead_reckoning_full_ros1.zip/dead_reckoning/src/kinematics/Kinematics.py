#!/usr/bin/env python3

import numpy as np

class Kinematics:
    def __init__(self, wheel_radius, rate):
        self.R = wheel_radius
        self.rate = rate

    def output_array_inverse(self, first_array, input_array, radius):
        return (60 / (2 * np.pi)) * (np.matmul((1 / radius) * first_array, input_array))
    

