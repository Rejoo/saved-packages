#!/usr/bin/env python3

import math
import rospy
from std_msgs.msg import Float32MultiArray
from nav_msgs.msg import Odometry
from geometry_msgs.msg import TransformStamped
from tf.transformations import quaternion_from_euler 
import tf2_ros


class Odom:
    def __init__(self):
        # self.wheel_radius = wheel_radius
        self.odom_seq = 0
        self.imu_seq = 0
        self.theta = 0
        self.theta_filtered = 0
        self.x = 0
        self.y = 0
        self.imu_x = 0
        self.imu_y = 0
        self.x_filtered = 0
        self.y_filtered = 0
        self.vx = 0
        self.vy = 0
        self.imu_vx = 0
        self.imu_vy = 0
        self.omega = 0
        self.acc_x = 0
        self.acc_y = 0
        self.roll = 0
        self.pitch = 0
        self.yaw_rad = 0
        self.wheels_rpm =[0,0,0,0]
        self.x, self.y, self.theta = 0.0, 0.0, 0.0
        self.vx, self.vy, self.omega = 0.0, 0.0, 0.0
        self.last_time = None
        
        self.imu_pub = rospy.Publisher('/imu/pose', Odometry, queue_size=10)
        self.odom_pub = rospy.Publisher('/odom', Odometry, queue_size=10)
        self.odom_pub_filtered = rospy.Publisher('/odom_filter', Odometry, queue_size=10)
        self.odom_broadcaster = tf2_ros.TransformBroadcaster()
        # rospy.Subscriber('/speed_feedback', Float32MultiArray, self.encoder_callback)
        rospy.Subscriber('/Espeeds', Float32MultiArray, self.encoder_callback)

    def calculate_dt(self):
        current_time = rospy.Time.now()
        if self.last_time is None:
            self.last_time = current_time
        dt = (current_time - self.last_time).to_sec()
        self.last_time = current_time
        return dt

    def encoder_callback(self, msg:Float32MultiArray):
        self.wheels_rpm = msg.data

        return self.wheels_rpm

    def rpm_to_angular(self,wheels_rpm):
        wheels_velocity = [(rpm * 2 * math.pi ) / 60 for rpm in wheels_rpm]
        return wheels_velocity

    def update_world_frame(self,vx,vy,omega,yaw_rad,dt):
        self.vx = vx
        self.vy = vy
        self.omega = omega
    
        vx_world = (vx * math.cos(yaw_rad)) - (vy * math.sin(yaw_rad))
        vy_world = (vx * math.sin(yaw_rad)) + (vy * math.cos(yaw_rad))

        dx = vx_world * dt
        dy = vy_world * dt
        dtheta = omega * dt

        self.x += dx
        self.y += dy
        self.theta += dtheta

        # rospy.loginfo(f" vx : {vx} , vy : {vy} ")
    def calc_imu_pose(self,acc_x,acc_y,dt):
        self.acc_x=acc_x
        self.acc_y=acc_y
        dvx =self.acc_x * dt
        dvy =self.acc_y * dt

        self.imu_vx += dvx
        self.imu_vy += dvy

        imu_vx_world = (self.imu_vx * math.cos(self.yaw_rad)) - (self.imu_vy * math.sin(self.yaw_rad))
        imu_vy_world = (self.imu_vx * math.sin(self.yaw_rad)) + (self.imu_vy * math.cos(self.yaw_rad))

        imu_dx = imu_vx_world * dt
        imu_dy = imu_vy_world * dt

        self.imu_x += imu_dx
        self.imu_y += imu_dy

    def publish_imu_pose(self):
        imu_msg = Odometry()
        imu_msg.header.seq = self.imu_seq
        imu_msg.header.stamp = rospy.Time.now()
        imu_msg.header.frame_id = "base_link"
        imu_msg.child_frame_id = "imu_link"

        imu_msg.twist.twist.linear.x = self.imu_vx
        imu_msg.twist.twist.linear.y = self.imu_vy
        imu_msg.twist.twist.angular.z = self.yaw_rad

        imu_msg.pose.pose.position.x = self.imu_x
        imu_msg.pose.pose.position.y = self.imu_y
        imu_msg.pose.pose.orientation.z = math.sin(self.theta / 2.0)
        imu_msg.pose.pose.orientation.w = math.cos(self.theta / 2.0)

        self.imu_pub.publish(imu_msg)
        self.imu_seq += 1


    def update_world_frame_filtered(self,vx,vy,omega,yaw_rad,dt):
        self.vx = vx
        self.vy = vy
        self.omega = omega
        self.yaw_rad = yaw_rad

        self.theta_filtered = 0.08 * (self.theta_filtered + omega * dt) + 0.92 * yaw_rad 

        fused_vx = 0.89 * vx + 0.11 * (self.vx + self.acc_x * dt) 
        fused_vy = 0.92 * vy + 0.08 * (self.vy + self.acc_y * dt)  
    
        vx_world_filtered = (fused_vx * math.cos( self.theta_filtered )) - (fused_vy * math.sin( self.theta_filtered ))
        vy_world_filtered= (fused_vx * math.sin( self.theta_filtered )) + (fused_vy * math.cos( self.theta_filtered ))

        dx_filterd = vx_world_filtered * dt
        dy_filterd = vy_world_filtered * dt

        self.x_filtered += dx_filterd
        self.y_filtered += dy_filterd
        
        self.vx_filtered, self.vy_filtered = fused_vx, fused_vy

        rospy.loginfo(f" vx : {vx} , vy : {vy} ")
        # rospy.loginfo(f"{self.x, self.y, self.theta}")

    def publish_odometry(self):    
        odom_msg = Odometry()
        odom_msg.header.seq = self.odom_seq
        odom_msg.header.stamp = rospy.Time.now()
        odom_msg.header.frame_id = "odom"
        odom_msg.child_frame_id = "base_link"

        odom_msg.twist.twist.linear.x = self.vx
        odom_msg.twist.twist.linear.y = self.vy
        odom_msg.twist.twist.angular.z = self.omega

        odom_msg.pose.pose.position.x = self.x
        odom_msg.pose.pose.position.y = self.y
        odom_msg.pose.pose.orientation.z = math.sin(self.yaw_rad  / 2.0)
        odom_msg.pose.pose.orientation.w = math.cos(self.yaw_rad  / 2.0)


        odom_trans = TransformStamped()

        odom_trans.header.stamp = rospy.Time.now()
        odom_trans.header.frame_id = "odom" 
        odom_trans.child_frame_id = "base_link"  

        odom_trans.transform.translation.x = self.x
        odom_trans.transform.translation.y = self.y
        odom_trans.transform.translation.z = 0.0

        odom_quat = quaternion_from_euler(0, 0, self.yaw_rad )

        odom_trans.transform.rotation.x = odom_quat[0]
        odom_trans.transform.rotation.y = odom_quat[1]
        odom_trans.transform.rotation.z = odom_quat[2]
        odom_trans.transform.rotation.w = odom_quat[3]

        self.odom_broadcaster.sendTransform(odom_trans)
        
        # rospy.loginfo(f" x : {self.x}")
        # rospy.loginfo(f"odom msg : {odom_msg}")
        self.odom_pub.publish(odom_msg)
        self.odom_seq += 1

    def publish_odom_filtered(self):    
        odom_filtered_msg = Odometry()
        odom_filtered_msg.header.seq = self.odom_seq
        odom_filtered_msg.header.stamp = rospy.Time.now()
        odom_filtered_msg.header.frame_id = "odom"
        odom_filtered_msg.child_frame_id = "base_link"

        # odom_trans = TransformStamped()
        # odom_trans.transform.translation.x = self.x_filtered
        # odom_trans.transform.translation.y = self.y_filtered
        # odom_trans.transform.translation.z = 0.0

        # odom_quat = quaternion_from_euler(0, 0, self.theta_filtered)

        # odom_trans.transform.rotation.x = odom_quat[0]
        # odom_trans.transform.rotation.y = odom_quat[1]
        # odom_trans.transform.rotation.z = odom_quat[2]
        # odom_trans.transform.rotation.w = odom_quat[3]

        # self.odom_broadcaster.sendTransform(odom_trans)

        odom_filtered_msg.twist.twist.linear.x = self.vx_filtered
        odom_filtered_msg.twist.twist.linear.y = self.vy_filtered
        odom_filtered_msg.twist.twist.angular.z = self.omega

        odom_filtered_msg.pose.pose.position.x = self.x_filtered
        odom_filtered_msg.pose.pose.position.y = self.y_filtered
        odom_filtered_msg.pose.pose.orientation.z = math.sin(self.theta_filtered  / 2.0)
        odom_filtered_msg.pose.pose.orientation.w = math.cos(self.theta_filtered / 2.0)
        
        self.odom_pub_filtered.publish(odom_filtered_msg)
        self.odom_seq += 1

