#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Twist
import sys
import select
import termios
import tty

msg = """
Control Your Robot!
---------------------------
Moving around:
   w    : Forward (vx)
   s    : Backward (vx)
   a    : Left (vy)
   d    : Right (vy)
   q    : Rotate left (theta)
   e    : Rotate right (theta)
   SPACE: Stop movement

Speed control:
   +    : Increase speed
   -    : Decrease speed

CTRL-C to quit
"""

# Key bindings (vx, vy, theta)
moveBindings = {
    'w': (1, 0, 0),   # Forward
    's': (-1, 0, 0),  # Backward
    'a': (0, 1, 0),   # Left
    'd': (0, -1, 0),  # Right
    'q': (0, 0, 1),   # Rotate left
    'e': (0, 0, -1),  # Rotate right
    ' ': (0, 0, 0),   # Stop (spacebar)
}

speedBindings = {
    '+': 1.1,  # Increase speed by 10%
    '-': 0.9,  # Decrease speed by 10%
}

class KeyboardControl:
    def __init__(self):
        self.settings = termios.tcgetattr(sys.stdin)
        self.vx = 0
        self.vy = 0
        self.theta = 0
        self.speed = 0.5
        # self.speed = 0.3
        self.turn = 1.0
        # self.turn = 0.5
        self.pub = rospy.Publisher('cmd_vel', Twist, queue_size=1)

    def getKey(self):
        tty.setraw(sys.stdin.fileno())
        list, _, _ = select.select([sys.stdin], [], [], 0.2)
        if list :
            key = sys.stdin.read(1)
        else :
            key = None
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.settings)
        return key
    
    def control_loop(self):
        rospy.init_node('simple_teleop')
        try:
            print(msg)
            while not rospy.is_shutdown():
                key = self.getKey()

                # if key :
                if key in moveBindings:
                    self.vx = moveBindings[key][0] * self.speed
                    self.vy = moveBindings[key][1] * self.speed
                    self.theta = moveBindings[key][2] * self.turn

                elif key in speedBindings:
                    self.speed *= speedBindings[key]  # Adjust linear speed
                    self.turn *= speedBindings[key]   # Adjust angular speed
                    print(f"Speed: {self.speed}, Turn: {self.turn}")
                elif key == '\x03':  # CTRL-C to exit
                    break
                else : 
                    self.vx, self.vy, self.theta = 0, 0, 0 

                # Create and publish Twist message
                twist = Twist()
                twist.linear.x = self.vx
                twist.linear.y = self.vy
                twist.angular.z = self.theta
                self.pub.publish(twist)

        except Exception as e:
            print(e)

        finally:
            self.stop_robot()

    def stop_robot(self): 
        twist = Twist()
        twist.linear.x = 0
        twist.linear.y = 0
        twist.angular.z = 0
        self.pub.publish(twist)
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.settings)


