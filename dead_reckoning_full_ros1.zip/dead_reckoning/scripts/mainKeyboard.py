#!/usr/bin/env python3

from keyboard.Keyboard import KeyboardControl

if __name__ == "__main__":
    kb_control = KeyboardControl()
    kb_control.control_loop()
