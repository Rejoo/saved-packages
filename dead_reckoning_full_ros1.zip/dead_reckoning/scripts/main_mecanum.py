#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Twist
from std_msgs.msg import Float32MultiArray
from kinematics.Mecanum_kinematics import KinematicsMecanum

def main():
    rospy.init_node('kinematics_mecanum_node')
    
    Lx = 0.15   
    Ly = 0.15  
    kinematics = KinematicsMecanum(Lx, Ly)

    # kinematics.pub = rospy.Publisher('/wheel_velocities', Float32MultiArray, queue_size=10)
    kinematics.pub = rospy.Publisher('/speed_setpoints', Float32MultiArray, queue_size=10)


    def callback(msg):
        Vx = msg.linear.x
        Vy = msg.linear.y
        W = msg.angular.z
                
        wheels_velocities = kinematics.wheel_velocities(Vx, Vy, W)
        
        wheels_velocities_msg = Float32MultiArray()
        wheels_velocities_msg.data = wheels_velocities.flatten()
        kinematics.pub.publish(wheels_velocities_msg)

    rospy.Subscriber("/cmd_vel", Twist, callback)

    rate = rospy.Rate(20)
    while not rospy.is_shutdown():
        rate.sleep()

if __name__ == '__main__':
    main()
