import numpy as np
import matplotlib.pyplot as plt
import time

Cd = 0.54
D = 0.24
A = (np.pi * D**2) / 4
rho = 1.204
m = 0.69
g = 9.81
dt = 0.01
dead_zone = 0.04  

pully_friction = 0.95

max_v = 20
min_v = 5.5
V_steps = 100
max_theta = 70
min_theta = 55
theta_steps = 200

def projectile(x_initial, x_target, y_initial, y_target):
    start_time = time.perf_counter()
    for V in np.linspace(min_v, max_v, V_steps):  
        for theta in np.linspace(min_theta, max_theta, theta_steps):  
            x, y = x_initial, y_initial
            vx = V * np.cos(np.radians(theta))
            vy = V * np.sin(np.radians(theta))

            trajectory_x = [] 
            trajectory_y = []  

            while y >= 0:      
                # v = np.sqrt(vx**2 + vy**2)
                R = 0.5 * Cd * rho * A * V

                ax = -(R * vx / m)
                ay = -g - (R * vy / m)

                vx += ax * dt
                vy += ay * dt

                x += vx * dt
                y += vy * dt

                trajectory_x.append(x)
                trajectory_y.append(y)
                if abs(x - x_target) <= dead_zone and abs(y - y_target) <= dead_zone:
                    plt.figure(figsize=(10, 6))
                    plt.plot(trajectory_x, trajectory_y, label=f"v={V:.4f}, θ={theta:.4f}°")
                    plt.scatter(x_target, y_target, color='red', label='Target')
                    plt.scatter(x, y, color='blue', label='reached')
                    plt.title('Projectile Motion with Air Resistance')
                    plt.xlabel('Distance (m)')
                    plt.ylabel('Height (m)')
                    plt.grid(True)
                    plt.legend()
                    plt.show()
                    pully_theta = 90 - theta
                    end_time = time.perf_counter()
                    diff = end_time - start_time
                    v_motor = V/pully_friction
                    v_ball = V
                    return {
                        'v_ball': v_ball,
                        'v_motor': v_motor,
                        'theta': theta,
                        'theta of pully' : pully_theta,
                        'diff' : diff
                    }

    return None  

# Try with target (7, 1.5)
result = projectile(0, 7, 0, 1.5)
if result:
    print(f"Projecting ball velocity : {result['v_ball']:.4f} m/s")
    print(f"Projecting motor velocity : {result['v_motor']:.4f} m/s")
    print(f"Projecting pitch angle : {result['theta']:.4f} degree")
    print(f"mechanism angle : {result['theta of pully']:.4f} degree")
    print(f"time taken is :{result['diff']:.04f}")
else:
    print("No solution found.")
