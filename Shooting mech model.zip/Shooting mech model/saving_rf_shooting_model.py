import joblib
import pandas as pd
from Shooting_model import ShootingModel

def main():
    rf_model=ShootingModel()

    df=pd.read_csv("Datasets\projectile_dataset6.csv")
    x_train, x_test, y_train, y_test = rf_model.preparing_data(df)
    rf_model.train(x_train, y_train )

    joblib.dump(rf_model, 'Models\shooting_model2.pkl')
    print("Model saved successfully")

if __name__=='__main__':
    main()