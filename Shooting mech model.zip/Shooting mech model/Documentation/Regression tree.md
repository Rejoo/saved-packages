# Regression Tree 
A Regression Tree is a decision tree algorithm used for predicting continuous values. It splits the dataset into smaller subsets by minimizing the error at each step, aiming to create an optimal structure for prediction.

## Steps to Construct a Regression Tree

1. Dividing Observations
* Try different threshold values for splitting the data.
* Calculate the Sum of Squared Residuals (SSR) at each step to determine the best split.
* SSR = ∑ ( Y_observed - Y_predicted )²
* The feature and threshold with the lowest SSR become candidates for the root of the tree.

2. Handling Multiple Predictors
* Find the optimal threshold for each predictor.
* Select the candidate with the smallest SSR to be the root node.

3. Stopping Criteria
* When a node has fewer than a predefined minimum number of observations, it becomes a leaf node.
* Otherwise, the splitting process continues 
* Until → We can no longer can split the data into smaller groups
We are Done.

4. Pruning a Regression Tree
* Pruning is applied to prevent overfitting to the training data.
* So that the tree does a better job with the testing data.