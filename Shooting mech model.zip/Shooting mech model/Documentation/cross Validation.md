# Cross-Validation
###  Instead of relying on one arbitrary split, cross-validation systematically rotates through different portions of the dataset for training and testing. 
### In this method:

1. The dataset is divided into multiple blocks.
2. One block is used for testing while the others are used for training.
3. This process repeats until every block has been used for testing at least once.
4. The results are then averaged to provide a more reliable evaluation of the model.

### Tuning Parameters Using Cross-Validation
Some machine learning methods, require tuning parameters that are not estimated but chosen. Cross-validation helps in selecting the optimal values for these parameters by testing different values and assessing their performance.