 # Prune regression trees 
  The goal of pruning is to improve the generalization of a regression tree by reducing overfitting and selecting the optimal tree size.

### 1. Overfitting and the Need for Pruning

A regression tree is initially built to fit training data, but if it grows too complex (too many leaves), it may overfit the training set, leading to poor generalization on test data. Pruning reduces the complexity of the tree by replacing detailed leaf nodes with broader averages.

### 2. Measuring Tree Performance

Tree performance is evaluated using the sum of squared residuals (SSR), which quantifies how well the tree fits the data. Larger trees tend to have lower SSR on training data but may not perform well on unseen data.

## 3. Cost Complexity Pruning (Weakest Link Pruning)

#### pruning process follows these steps:

  * Calculate SSR for the tree at different sizes.

  * Introduce a complexity penalty to balance model accuracy and simplicity.

![alt text](image.png)

where **α** is a **tuning parameter** that controls the penalty for complexity.
the value for alpha makes a difference in our choice of subtree.

#### Incrementally Increasing Alpha and Pruning the Tree

    Initially, when α = 0, the tree is fully grown since it has the lowest tree score.
    As α increases, pruning occurs where removing leaves results in a lower tree score.

    This process creates a sequence of trees, from the full-sized version down to a single leaf tree.
    
#### Training and Testing the Trees
 1. The dataset is split into training and testing data.
 2. Using the training data, a full decision tree is built, followed by a sequence of pruned sub-trees corresponding to different α values.
 3. For each α value, a new tree is tested:

    α = 0 results in the full tree, having the lowest tree score initially.

    by further increasing α ==> pruned trees achieves a lower tree score than before.

    till the single leaf tree get the lowest tree score 
#### Evaluating the Trees with Testing Data
SSR is calculated for each pruned tree using only the testing data.
### 4. Cross-Validation to Determine the Optimal Alpha
The training and testing process is repeated with new training and testing splits from the same dataset.
This process is repeated for 10-fold cross-validation to identify the α value that minimizes SSR on average.

where the SSR is first calculated for all pruned trees in each fold, and then the average SSR for a specific α is computed across all 10 iterations

### 5. Selecting the Final Pruned Tree
After selecting the optimal α, the pruned tree with the lowest SSR is chosen as the final model.

