import joblib
import time


rf_model = joblib.load('Models/shooting_model.pkl')

x = 2.5
y = 1.5

start_time = time.perf_counter()
prediction =  rf_model.output(x, y)
end_time = time.perf_counter()

diff_time = end_time - start_time
print("Prediction for new input: ")
print(f"Velocity (v): {prediction['v']:.3f}")
print(f"Angle (theta): {prediction['theta']:.3f}")
print(f"Time taken: {diff_time:.4f}")
