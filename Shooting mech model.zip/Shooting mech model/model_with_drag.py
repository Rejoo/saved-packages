import numpy as np
import matplotlib.pyplot as plt
import time

Cd = 0.54
D_ball = 0.24
A = (np.pi * D_ball**2) / 4
rho = 1.204
m = 0.69
g = 9.81
dt = 0.01
dead_zone = 0.04  

def projectile(x_initial, x_target, y_initial, y_target):
    start_time = time.perf_counter()
    for V in np.linspace(5.5, 11.2, 100):  
        for theta in np.linspace(52, 70, 200):  
            x, y = x_initial, y_initial
            vx = V * np.cos(np.radians(theta))
            vy = V * np.sin(np.radians(theta))

            trajectory_x = [] 
            trajectory_y = []  

            while y >= 0:      
                # v = np.sqrt(vx**2 + vy**2)
                R = 0.5 * Cd * rho * A * V

                ax = -(R * vx / m)
                ay = -g - (R * vy / m)

                vx += ax * dt
                vy += ay * dt

                x += vx * dt
                y += vy * dt

                trajectory_x.append(x)
                trajectory_y.append(y)
                if abs(x - x_target) <= dead_zone and abs(y - y_target) <= dead_zone:
                    # plt.figure(figsize=(10, 6))
                    # plt.plot(trajectory_x, trajectory_y, label=f"v={V:.4f}, θ={theta:.4f}°")
                    # plt.scatter(x_target, y_target, color='red', label='Target')
                    # plt.scatter(x, y, color='blue', label='reached')
                    # plt.title('Projectile Motion with Air Resistance')
                    # plt.xlabel('Distance (m)')
                    # plt.ylabel('Height (m)')
                    # plt.grid(True)
                    # plt.legend()
                    # plt.show()
                    pully_theta = 90 - theta
                    end_time = time.perf_counter()
                    diff = end_time - start_time
                    return {
                        'v': V,
                        'theta': theta,
                        'theta of pully' : pully_theta,
                        'diff' : diff
                    }

    return None 
def mechanism_outputs(target_x, target_y):
    roller_friction = 0.95
    D_roller = 0.075
    RPM = (D_roller*np.pi)/60
    motor_efficiency = 0.95
    motor_to_roller_ratio = 1

    predictions = projectile(0, target_x, 0, target_y)

    v_roller_RPM = (predictions['v'] / roller_friction) / RPM
    v_motor_RPM = (v_roller_RPM * motor_to_roller_ratio) / motor_efficiency
    v_roller = (predictions['v'] / roller_friction)
    v_motor = (v_roller * motor_to_roller_ratio) / motor_efficiency
    theta_mechanism = 90 - predictions['theta']

    return {
        'v_motor_RPM' : v_motor_RPM,
        'v_roller_RPM' : v_roller_RPM,
        'v_motor' : v_motor,
        'v_roller' : v_roller,
        'theta_mechanism' : theta_mechanism
    } 

# Try with target (7, 1.5)
x = 2.5
y = 1.5
result = projectile(0, x, 0, y)
if result:
    print(f"Projecting velocity : {result['v']:.4f} m/s")
    print(f"Projecting pitch angle : {result['theta']:.4f} degree")
    print(f"mechanism angle : {result['theta of pully']:.4f} degree")
    print(f"time taken is :{result['diff']:.04f}")
    
    mechanism = mechanism_outputs(x, y)
    print(f"v motor RPM : {mechanism['v_motor_RPM']:.4f} rpm")
    print(f"v roller RPM : {mechanism['v_roller_RPM']:.4f} rpm")
    print(f"v motor : {mechanism['v_motor']:.4f} m/s")
    print(f"v roller : {mechanism['v_roller']:.4f} m/s")
    print(f"mechanism angle : {mechanism['theta_mechanism']:.4f} degree")
else:
    print("No solution found.")
