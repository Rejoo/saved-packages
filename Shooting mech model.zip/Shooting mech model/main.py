from model_with_drag import projectile

if __name__ == "__main__":
    x_initial = float(input("Enter the initial x-coordinate (meters):"))
    x_target = float(input("Enter the target x-coordinate (meters): "))
    y_initial = float(input("Enter the initial y-coordinate (meters)"))
    y_target = float(input("Enter the target y-coordinate (meters): "))

    # max target (7, 1.5)
    result = projectile(x_initial, x_target, y_initial, y_target)
    if result:
        print(f"Projecting velocity : {result['v']:.4f} m/s")
        print(f"Projecting pitch angle : {result['theta']:.4f} degree")
    else:
        print("No solution found.")