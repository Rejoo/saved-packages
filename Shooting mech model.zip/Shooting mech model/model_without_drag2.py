import numpy as np
import time 


def solve_theta_v0(x0, x, y0, y):
    # Calculate L and h
    L = x - x0
    h = y - y0

    # coefficients for tan(theta)
    def coefficients(v0):
        g=9.81
        a = 1  
        b = -2 * v0**2 / (g * L)  
        c = (2 * v0**2 * h) / (g * L**2) + 1 
        return a, b, c


    start_time=time.perf_counter()
    for v0 in np.linspace(5.5, 20, 1000): 
        a, b, c = coefficients(v0)
        # Solve the quadratic equation: a*tan^2(theta) + b*tan(theta) + c = 0
        discriminant = b**2 - 4 * a * c

        if discriminant >= 0:  # Check if solutions exist
            tan_theta_1 = (-b + np.sqrt(discriminant)) / (2 * a)
            tan_theta_2 = (-b - np.sqrt(discriminant)) / (2 * a)

            # tan inverse
            theta_1 = np.arctan(tan_theta_1)
            theta_2 = np.arctan(tan_theta_2)

            # print(f"v0: {v0:.2f}, tan_theta_1: {tan_theta_1:.2f}, tan_theta_2: {tan_theta_2:.2f}")
            # print(f"theta_1: {np.degrees(theta_1):.2f} degrees, theta_2: {np.degrees(theta_2):.2f} degrees")

            if theta_1 >= 0 and theta_2 >= 0:
                if 52 <= np.degrees(theta_1) <= 70 :
                    end_time = time.perf_counter()
                    diff = end_time-start_time
                    print(f"Time taken : {diff :.6f}")
                    return {
                        'v0': v0,
                        'theta': np.degrees(theta_1),
                    }   
                elif 52 <= np.degrees(theta_2) <= 70 :
                    end_time = time.perf_counter()
                    diff = end_time-start_time
                    print(f"Time taken : {diff :.6f}")
                    return {
                        'v0': v0,
                        'theta': np.degrees(theta_2),
                    }


    return None  # No solution found

result = solve_theta_v0(0, 2.5, 0, 1.5)
if result:
    print(f"Initial velocity (v0): {result['v0']:.2f} m/s")
    print(f"Angle 1 (theta_1): {result['theta']:.2f} degrees")
else:
    print("No solution found.")
