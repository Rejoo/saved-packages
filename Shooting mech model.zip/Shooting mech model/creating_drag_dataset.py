import numpy as np
import pandas as pd
from model_with_drag import projectile
import random

# Assuming `dataset` is already initialized
i = 0
dataset = []

#creating dataset
for _ in range(60):  
    x = random.uniform(0.5, 7)  
    y = 1.5 
    result = projectile(0, x, 0, y)
    
    print(i)
    i += 1
    if result:
        dataset.append({
            'x': x,
            'y': y,
            'v': result['v'],
            'theta': result['theta']
        })


df = pd.DataFrame(dataset)
df = df.sample(frac=1, random_state=42).reset_index(drop=True)
print(df.head)
df.to_csv('Datasets\projectile_dataset7.csv', index=False)



