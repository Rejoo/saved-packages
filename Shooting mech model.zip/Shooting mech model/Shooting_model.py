import pandas as pd 
import numpy as np 
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score 
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

class ShootingModel:
    def __init__(self):
        self.pipeline = None
        self.best_parameters = None

    def plot_data(self, df):
        plt.figure(figsize=(7,7))

        # x vs v
        plt.subplot(2, 2, 1)
        plt.scatter(df['x'], df['v'], alpha=0.5)
        plt.xlabel('X position')
        plt.ylabel('Velocity')
        plt.title('X vs Velocity')

        # y vs v
        plt.subplot(2, 2, 2)
        plt.scatter(df['y'], df['v'], alpha=0.5)
        plt.xlabel('Y position')
        plt.ylabel('Velocity')
        plt.title('Y vs Velocity')

        # x vs theta
        plt.subplot(2, 2, 3)
        plt.scatter(df['x'], df['theta'], alpha=0.5)
        plt.xlabel('X position')
        plt.ylabel('Theta')
        plt.title('X vs Theta')

        # y vs theta
        plt.subplot(2, 2, 4)
        plt.scatter(df['y'], df['theta'], alpha=0.5)
        plt.xlabel('Y position')
        plt.ylabel('Theta')
        plt.title('Y vs Theta')

        plt.tight_layout()
        plt.show()

    def preparing_data (self, df):
        x = df.iloc[:, 0:2].values 
        y = df.iloc[:, 2:].values 
        return train_test_split(x, y, test_size=0.2, random_state=42)
    
    def create_pipeline(self):
        return Pipeline([
            ('scaler', StandardScaler()),
            ('rf', RandomForestRegressor(random_state=42))
        ])
    
    def train(self, x_train, y_train):
        self.pipeline = self.create_pipeline()

        param = {
            'rf__n_estimators': [50, 100, 200],
            'rf__max_depth': [10, 20, None],
            'rf__min_samples_split': [2, 5, 10],
            'rf__min_samples_leaf': [1, 2, 4]
        }

        grid_search = GridSearchCV(
            self.pipeline,
            param, 
            cv=5,
            scoring='r2',
            n_jobs=-1
        )

        grid_search.fit(x_train, y_train)
        self.pipeline = grid_search.best_estimator_
        self.best_parameters = grid_search.best_params_

        return self.pipeline
    
    def predict(self, features):
        return self.pipeline.predict(features)

    def evaluate(self, x_test, y_test):
        y_pred_test = self.predict(x_test)

        results = {
            'R2' : r2_score(y_test,y_pred_test),
            'MSE' : mean_squared_error(y_test,y_pred_test),
            'RMSE' : np.sqrt(mean_squared_error(y_test,y_pred_test))
        }

        return results 

    def plot_evaluation(self, x_test, y_test):
        y_pred_test = self.predict(x_test)
        plt.figure(figsize=(7,7))

        # v test vs v predict
        plt.subplot(1, 2, 1)
        plt.scatter(y_test[:, 0], y_pred_test[:, 0], alpha=0.5)
        plt.plot([y_test[:, 0].min(), y_test[:, 0].max()], 
        [y_test[:, 0].min(), y_test[:, 0].max()], 
        'r--', lw=2)
        plt.xlabel('V test')
        plt.ylabel('V predict')
        plt.title('V test vs V predict')

        # Theta test vs Theta predict
        plt.subplot(1, 2, 2)
        plt.scatter(y_test[:, 1], y_pred_test[:, 1], alpha=0.5)
        plt.plot([y_test[:, 1].min(), y_test[:, 1].max()], 
        [y_test[:, 1].min(), y_test[:, 1].max()], 
        'r--', lw=2)
        plt.xlabel('Theta test')
        plt.ylabel('Theta predict')
        plt.title('Theta test vs Theta predict')

        plt.tight_layout()
        plt.show()

    def plot_evaluation2(self, x_test, y_test):
        y_pred_test = self.predict(x_test)

        plt.rcParams['figure.figsize']=(10,5)
        x_ax = range(len(x_test))

        # Plot predicted values
        plt.plot(x_ax, y_pred_test[:, 0], label='Predicted v', color='r', linestyle='--')
        plt.plot(x_ax, y_pred_test[:, 1], label='Predicted theta', color='b', linestyle='--')
        plt.plot(x_ax, y_test[:, 0], label ='Observed v', color = 'g' , linestyle = '-')
        plt.plot(x_ax, y_test[:, 1], label ='Observed theta', color = 'k' , linestyle = '-')

        # Add labels, legend, and title
        plt.xlabel('Test Sample')
        plt.ylabel('Target Value')
        plt.title('Observed vs. Predicted Values')
        plt.legend()

        # Show the plot
        plt.show()
    def output(self, target_x, target_y):
        x_input = np.array([[target_x, target_y]])
        y_output = self.predict(x_input)

        results = {
            'v' : y_output[0][0],
            'theta' : y_output[0][1]
        }

        return results
    
    def accurate_output(self, target_x, target_y, n_samples=1000):
        # Create a grid of possible target positions
        X_grid = np.array([[target_x, target_y]] * n_samples)
        predictions = self.predict(X_grid)
        
        # Return mean prediction as our best estimate
        mean_prediction = np.mean(predictions, axis=0)
        return {
            'v': mean_prediction[0],
            'theta': mean_prediction[1]
        }
    
    def mechanism_outputs(self, target_x, target_y):
        roller_friction = 0.95
        D_roller = 0.075
        RPM = (D_roller*np.pi)/60
        motor_efficiency = 0.95
        motor_to_roller_ratio = 1

        predictions = self.output(target_x, target_y)

        v_roller_RPM = (predictions['v'] / roller_friction)/RPM
        v_motor_RPM = (v_roller_RPM * motor_to_roller_ratio) / motor_efficiency
        v_roller = (predictions['v'] / roller_friction)
        v_motor = (v_roller * motor_to_roller_ratio) / motor_efficiency
        theta_mechanism = 90 - predictions['theta']

        return {
            'v_motor_RPM' : v_motor_RPM,
            'v_roller_RPM' : v_roller_RPM,
            'v_motor' : v_motor,
            'v_roller' : v_roller,
            'theta_mechanism' : theta_mechanism
        }

def main():
    rf_model = ShootingModel()

    df = pd.read_csv('Datasets\projectile_dataset6.csv')
    # rf_model.plot_data(df)
    x_train, x_test, y_train, y_test = rf_model.preparing_data(df)
    rf_model.train(x_train, y_train)

    evalutions_param = rf_model.evaluate(x_test, y_test)
    print("Model evaluation")
    print(f"R2 : {evalutions_param['R2']:.3f}")
    print(f"MSE : {evalutions_param['MSE']:.3f}")
    print(f"RMSE : {evalutions_param['RMSE']:.3f}")

    # rf_model.plot_evaluation(x_test, y_test)
    # rf_model.plot_evaluation2(x_test, y_test)

    #Test
    prediction = rf_model.output(2.5,1.5)
    print("Model Outputs")
    print(f"v : {prediction['v']:.3f}")
    print(f"theta : {prediction['theta']:.3f}")
    #or to remove randomness
    accurate_prediction=rf_model.accurate_output(2.5,1.5) # no diffrenece asasan ??
    print("Model accurate Outputs")
    print(f"v : {accurate_prediction['v']:.3f}")
    print(f"theta : {accurate_prediction['theta']:.3f}")
    #mechanism
    mechanism = rf_model.mechanism_outputs(2.5,1.5)
    print("Mechanism Model Outputs")
    print(f"v motor RPM: {mechanism['v_motor_RPM']:.3f}")
    print(f"v roller RPM: {mechanism['v_roller_RPM']:.3f}")
    print(f"v motor : {mechanism['v_motor']:.3f}")
    print(f"v roller : {mechanism['v_roller']:.3f}")
    print(f"theta mechanism : {mechanism['theta_mechanism']:.3f}")


if __name__=='__main__':
    main()