import numpy as np
import pandas as pd
from model_without_drag2 import solve_theta_v0
import random

# Assuming `dataset` is already initialized
i = 0
dataset = []

#creating dataset
for _ in range(60):  
    x = random.uniform(0, 7)  
    y = 1.5 
    result = solve_theta_v0(0, x, 0, y)
    
    print(i)
    i += 1
    if result:
        dataset.append({
            'x': x,
            'y': y,
            'v': result['v0'],
            'theta': result['theta']
        })


df = pd.DataFrame(dataset)
df = df.sample(frac=1, random_state=42).reset_index(drop=True)
print(df.head)
df.to_csv('Datasets\projectile_dataset8.csv', index=False)
