#include "dcDriver.h"

dcDriver::dcDriver() : speed(0), direction(STOP) {}

void dcDriver::setSpeed(float speedVal) {
    speedVal = constrain(speedVal,MIN_PWM,MAX_PWM);
    this->speed = abs(speedVal);
    if (speedVal > 0)
        this->direction = FORWARD;
    else if (speedVal < 0)
        this->direction = REVERSE;
    else
        this->direction = STOP;
}

float dcDriver::getSpeed() const {
    return speed;
}

dcDriver::Direction dcDriver::getDirection() const {
    return direction;
}