#include "cytron.h"

cytron::cytron(long DIR, long PWM) : dcDriver(), DIR(DIR), PWM(PWM) {
    pinMode(DIR, OUTPUT);
    pinMode(PWM, OUTPUT);
}

void  cytron::controlMotor() const {
    if (this->direction == FORWARD) {
        digitalWrite(DIR, HIGH);
        analogWrite(PWM, this->speed);
    } else if (this->direction == REVERSE) {
        digitalWrite(DIR, LOW);
        analogWrite(PWM, this->speed);
    } else {
        analogWrite(PWM, 0);
    }
}