#ifndef PIDCONTROLLER_H
#define PIDCONTROLLER_H

#include <ros.h>
#include <std_msgs/Float32.h>
#include <std_msgs/Float32MultiArray.h>

class PID {
protected:
    float kp, ki, kd;  // PID gains
    float setpoint,feedback, output;
    float previousError, integral, deltaTime, deadzone;
    float error;
    ros::NodeHandle* nh;
    float maxIntegralError = 500;
    float maxOutput = 500;
    float derivative;

public:
    PID(float kp, float ki, float kd, float deltaTime, float deadzone, ros::NodeHandle* nodeHandle);
    
    void setSetpoint(float desiredSetpoint);
    void setFeedback(float measuredFeedback);
    void setParameters(float newKp, float newKi, float newKd);
    float compute();
};
// class pid_ros : public PID {
// private:
//     std_msgs::Float32MultiArray pid_output_msg;
//     std_msgs::Float32MultiArray pidGraphMessage;

//     ros::Publisher pid_output_pub;
//     ros::Subscriber<std_msgs::Float32MultiArray,pid_ros> pid_param_sub;
//     ros::NodeHandle* nh ;

//     // Static callback function
//     void handlePIDParameters(const std_msgs::Float32MultiArray &msg);
    
// public:
//     pid_ros(float kp, float ki, float kd, float deltaTime, ros::NodeHandle* nh);

//     void publishOutput();
// };

#endif  // PIDCONTROLLER_H