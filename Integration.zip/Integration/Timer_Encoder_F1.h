#ifndef TIMER_ENCODER_F1_H
#define TIMER_ENCODER_F1_H

#define __STM32F1__

#include "Timer_Encoder.h"

class Timer_Encoder_F1 : public Timer_Encoder
{

    public:

    /**
     * @brief the constructor of the timer encoder class
     * @param resolution the resolution of the encoder
     * @param timer_index the timer for stm32 (ex:Timer_1)
    */
    Timer_Encoder_F1(float resolution, stm_timer_t timer_index);

    /**
     * @brief method for updating counts of the encoder
    */
    void update_counts();

    /**
     * @brief method for encoder setup
    */
    void setup();

    private:
    stm_timer_t timer_index;    ///<the timer index (ex:Timer_1)
};

#endif
