#ifndef L298_H
#define L298_H

#include "dcDriver.h"

class L298 : public dcDriver {
private:
    int enablePin, input1Pin, input2Pin;

public:
    L298(int en, int in1, int in2);
    void controlMotor() const override;
};
#endif