// Initial PID parameters
// data: [400,6.2,0.035,450,6.2,0.03,410,6.2,0.01,390,7.1,0.015] "

// wheel 0 after tuning
#define KP1_INITIAL      0
#define KI1_INITIAL      0
#define KD1_INITIAL      0
// wheel 1 after tuning
#define KP2_INITIAL      0
#define KI2_INITIAL      0
#define KD2_INITIAL      0
// WHEEL 2 AFTER
#define KP3_INITIAL      0
#define KI3_INITIAL      0
#define KD3_INITIAL      0
// weel 3 After tuning 
#define KP4_INITIAL      0.15
#define KI4_INITIAL      0.0
#define KD4_INITIAL      0.0

#define NUMBER_OF_MOTORS 4
#define RESOLUTION 32767
#define minOut -65535
#define maxOut 65535
#define SAMPLING_TIME_MS 10 
#define SAMPLING_TIME_SEC 0.01
#define SECONDS_IN_MINUTE 60
#define MILLIS_IN_SECOND 1000
// Encoder Resolution
#define ENCODER_RESOLUTION 8200

// Encoder Pins for Motors
// #define ENCODER1_PIN_A PA0
// #define ENCODER1_PIN_B PA1
// #define ENCODER2_PIN_A PB6
// #define ENCODER2_PIN_B PB7
// #define ENCODER3_PIN_A PA6 //
// #define ENCODER3_PIN_B PA7 //
// #define ENCODER4_PIN_A PA8 //
// #define ENCODER4_PIN_B PA9 //

// Motor Control Pins
#define MOTOR1_DIR_PIN PA5
#define MOTOR1_PWM_PIN PA2

#define MOTOR2_DIR_PIN  PB5
#define MOTOR2_PWM_PIN  PB3

#define MOTOR3_DIR_PIN PA4
#define MOTOR3_PWM_PIN PA3
//
// #define MOTOR4_DIR_PIN  PB8
#define MOTOR4_DIR_PIN  PA10
#define MOTOR4_PWM_PIN  PA15





#define MOTOR0_TIMER TIMER_5
#define MOTOR1_TIMER TIMER_4
#define MOTOR2_TIMER TIMER_3
#define MOTOR3_TIMER TIMER_1 