#include "Timer_Encoder.h"

Timer_Encoder::Timer_Encoder(float resolution, stm_timer_t timer_index) : Encoder(resolution)
{
    this->timer_index = timer_index;
}

void Timer_Encoder::setup()
{
    #if defined(__STM32F1__)

    switch (timer_index)
    {
    case TIMER_1:

        RCC->APB2ENR |= RCC_APB2ENR_TIM1EN; //enabling timer 1 from advanced peripheral clock enable register

        TIM1->ARR = 0xFFFF;                 //setting the autoreload register to maximum value for the overflow 0-65535

        TIM1->CCMR1 |= (TIM_CCMR1_CC1S_0 | TIM_CCMR1_CC2S_0); //configuring channel 1 and channel 2 as input on thier trigger
        TIM1->CCER &= ~(TIM_CCER_CC1P | TIM_CCER_CC2P);       //choosing active high trigger on channel 1 and channel 2
        TIM1->SMCR |= TIM_SMCR_SMS_0 | TIM_SMCR_SMS_1;        //choosing slave mode selection which allows counter to counts up/down for both channels depending on the inputs
        TIM1->CR1 |= TIM_CR1_CEN;                             //enabling counter from timer control register
        break;

    case TIMER_2:

        RCC->APB1ENR |= RCC_APB1ENR_TIM2EN; 
        
        TIM2->ARR = 0xFFFF;

        TIM2->CCMR1 |= (TIM_CCMR1_CC1S_0 | TIM_CCMR1_CC2S_0); 
        TIM2->CCER &= ~(TIM_CCER_CC1P | TIM_CCER_CC2P);       
        TIM2->SMCR |= TIM_SMCR_SMS_0 | TIM_SMCR_SMS_1;       
        TIM2->CR1 |= TIM_CR1_CEN;                             
        break;

    case TIMER_3:

        RCC->APB1ENR |= RCC_APB1ENR_TIM3EN; 

        TIM3->ARR = 0xFFFF;

        TIM3->CCMR1 |= (TIM_CCMR1_CC1S_0 | TIM_CCMR1_CC2S_0); 
        TIM3->CCER &= ~(TIM_CCER_CC1P | TIM_CCER_CC2P);      
        TIM3->SMCR |= TIM_SMCR_SMS_0 | TIM_SMCR_SMS_1;      
        TIM3->CR1 |= TIM_CR1_CEN;
        break;

    case TIMER_4:

        RCC->APB1ENR |= RCC_APB1ENR_TIM4EN; 

        TIM4->ARR = 0xFFFF;

        TIM4->CCMR1 |= (TIM_CCMR1_CC1S_0 | TIM_CCMR1_CC2S_0);
        TIM4->CCER &= ~(TIM_CCER_CC1P | TIM_CCER_CC2P);      
        TIM4->SMCR |= TIM_SMCR_SMS_0 | TIM_SMCR_SMS_1; 
        TIM4->CR1 |= TIM_CR1_CEN;
        break;

    default:
        break;
    }

    #elif defined(__STM32F4__)

        switch(timer_index)
        {
        case TIMER_1:

        RCC->APB2ENR |= RCC_APB2ENR_TIM1EN; //enabling timer 1 from advanced peripheral clock enable register
        RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN; //enabling port A clock from peripheral clock enable register 
        // GPIOA->MODER |= 0xA0000;
        GPIOA->MODER |= (GPIO_MODER_MODER8_1 | GPIO_MODER_MODER9_1);     //setting PA8, PA9 in alternative function mode
        GPIOA->AFR[1] |= (GPIO_AFRH_AFRH0_0 | GPIO_AFRH_AFRH1_0);       //mapping A8,A9 pins to the timer alternative function from alternate function high register

        TIM1->ARR = 0xFFFF;                 //setting the autoreload register to maximum value for the overflow 0-65535

        TIM1->CCMR1 |= (TIM_CCMR1_CC1S_0 | TIM_CCMR1_CC2S_0); //configuring channel 1 and channel 2 as input on thier trigger
        TIM1->CCER &= ~(TIM_CCER_CC1P | TIM_CCER_CC2P);       //choosing active high trigger on channel 1 and channel 2
        TIM1->SMCR |= TIM_SMCR_SMS_0 | TIM_SMCR_SMS_1;        //choosing slave mode selection which allows counter to counts up/down for both channels depending on the inputs
        TIM1->CR1 |= TIM_CR1_CEN;                             //enabling counter from timer control register
        break;

        case TIMER_2:
    
            RCC->APB1ENR |= RCC_APB1ENR_TIM2EN; 
            RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN | RCC_AHB1ENR_GPIOBEN;
            // GPIOA->MODER |= 0x80000000;
            // GPIOB->MODER |= 0x8A;
            // GPIOA->MODER |= 0xA;
            GPIOA->MODER |= (GPIO_MODER_MODER0_1 | GPIO_MODER_MODER1_1);
            // GPIOB->AFR[0] |= GPIO_AFRL_AFRL3_0;
            // GPIOA->AFR[1] |= GPIO_AFRH_AFRH7_0;
            GPIOA->AFR[0] |= (GPIO_AFRL_AFRL0_0 | GPIO_AFRL_AFRL1_0);
    
            TIM2->ARR = 0xFFFFFFFF;
    
            TIM2->CCMR1 |= (TIM_CCMR1_CC1S_0 | TIM_CCMR1_CC2S_0);
            TIM2->CCER &= ~(TIM_CCER_CC1P | TIM_CCER_CC2P);       
            TIM2->SMCR |= TIM_SMCR_SMS_0 | TIM_SMCR_SMS_1;       
            TIM2->CR1 |= TIM_CR1_CEN;                             
            break;
    
        case TIMER_3:
    
            RCC->APB1ENR |= RCC_APB1ENR_TIM3EN; 
            RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
            // GPIOA->MODER |= 0xA000;
            GPIOA->MODER |= (GPIO_MODER_MODER6_1 | GPIO_MODER_MODER7_1);
            GPIOA->AFR[0] |= (GPIO_AFRL_AFRL6_1 | GPIO_AFRL_AFRL7_1);
    
            TIM3->ARR = 0xFFFF;
    
            TIM3->CCMR1 |= (TIM_CCMR1_CC1S_0 | TIM_CCMR1_CC2S_0); 
            TIM3->CCMR1 &= ~(TIM_CCMR1_IC1F | TIM_CCMR1_IC2F);
            TIM3->CCER &= ~(TIM_CCER_CC1P | TIM_CCER_CC2P);      
            TIM3->SMCR |= TIM_SMCR_SMS_0 | TIM_SMCR_SMS_1;      
            TIM3->CR1 |= TIM_CR1_CEN;
            break;
    
        case TIMER_4:
    
            RCC->APB1ENR |= RCC_APB1ENR_TIM4EN;
            RCC->AHB1ENR |= RCC_AHB1ENR_GPIOBEN; 
            // GPIOB->MODER |= 0xA000;
            GPIOB->MODER |= (GPIO_MODER_MODER6_1 | GPIO_MODER_MODER7_1);
            GPIOB->AFR[0] |= (GPIO_AFRL_AFRL6_1 | GPIO_AFRL_AFRL7_1);
    
            TIM4->ARR = 0xFFFF;
    
            TIM4->CCMR1 |= (TIM_CCMR1_CC1S_0 | TIM_CCMR1_CC2S_0);
            TIM4->CCER &= ~(TIM_CCER_CC1P | TIM_CCER_CC2P);      
            TIM4->SMCR |= TIM_SMCR_SMS_0 | TIM_SMCR_SMS_1; 
            TIM4->CR1 |= TIM_CR1_CEN;
            break;
            
        case TIMER_5:
    
            RCC->APB1ENR |= RCC_APB1ENR_TIM5EN; 
            RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
            // GPIOA->MODER |= 0XA;
            GPIOA->MODER |= (GPIO_MODER_MODER0_1 | GPIO_MODER_MODER1_1);
            GPIOA->AFR[0] |= (GPIO_AFRL_AFRL0_1 | GPIO_AFRL_AFRL1_1);
    
            TIM5->ARR = 0xFFFFFFFF;
    
            TIM5->CCMR1 |= (TIM_CCMR1_CC1S_0 | TIM_CCMR1_CC2S_0);
            TIM5->CCER &= ~(TIM_CCER_CC1P | TIM_CCER_CC2P);      
            TIM5->SMCR |= TIM_SMCR_SMS_0 | TIM_SMCR_SMS_1; 
            TIM5->CR1 |= TIM_CR1_CEN;
            break;

        default:
            break;
        }

    #endif 
}

void Timer_Encoder::update_counts()
{
    #if defined(__STM32F1__)

    switch (timer_index)
    {
    case TIMER_1:                         
        encodercount += (int16_t)TIM1->CNT; // Storing counts
        TIM1->CNT = 0;                      //resetting the timer to prevent the overflow
        break;

    case TIMER_2:                         
        encodercount += (int16_t)TIM2->CNT;
        TIM2->CNT = 0;
        break;

    case TIMER_3:                         
        encodercount += (int16_t)TIM3->CNT;
        TIM3->CNT = 0;
        break;

    case TIMER_4:                       
        encodercount += (int16_t)TIM4->CNT;
        TIM4->CNT = 0;
        break;
    
    default:
        break;
    }

    #elif defined(__STM32F4__)

    switch (timer_index)
    {
        case TIMER_1:                         
            encodercount += (int16_t)TIM1->CNT; // Storing counts
            TIM1->CNT = 0;                      //resetting the timer to prevent the overflow
            break;

        case TIMER_2:                         
            encodercount += (int32_t)TIM2->CNT;
            TIM2->CNT = 0;
            break;

        case TIMER_3:                         
            encodercount += (int16_t)TIM3->CNT;
            TIM3->CNT = 0;
            break;

        case TIMER_4:                       
            encodercount += (int16_t)TIM4->CNT;
            TIM4->CNT = 0;
            break;

        case TIMER_5:                       
            encodercount += (int32_t)TIM5->CNT;
            TIM5->CNT = 0;
            break;    

        default:
            break;
    }

    #endif
}