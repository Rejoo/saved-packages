#include "Timer_Encoder_F1.h"

Timer_Encoder_F1::Timer_Encoder_F1(float resolution, stm_timer_t timer_index) : Timer_Encoder(resolution,timer_index)
{
    this->timer_index = timer_index;
}

void Timer_Encoder_F1::setup()
{
    switch (timer_index)
    {
        case TIMER_1:

            RCC->APB2ENR |= RCC_APB2ENR_TIM1EN; //enabling timer 1 from advanced peripheral clock enable register

            TIM1->ARR = 0xFFFF;                 //setting the autoreload register to maximum value for the overflow 0-65535

            TIM1->CCMR1 |= (TIM_CCMR1_CC1S_0 | TIM_CCMR1_CC2S_0); //configuring channel 1 and channel 2 as input on thier trigger
            TIM1->CCER &= ~(TIM_CCER_CC1P | TIM_CCER_CC2P);       //choosing active high trigger on channel 1 and channel 2
            TIM1->SMCR |= TIM_SMCR_SMS_0 | TIM_SMCR_SMS_1;        //choosing slave mode selection which allows counter to counts up/down for both channels depending on the inputs
            TIM1->CR1 |= TIM_CR1_CEN;                             //enabling counter from timer control register
            break;

        case TIMER_2:

            RCC->APB1ENR |= RCC_APB1ENR_TIM2EN; 
            
            TIM2->ARR = 0xFFFF;

            TIM2->CCMR1 |= (TIM_CCMR1_CC1S_0 | TIM_CCMR1_CC2S_0); 
            TIM2->CCER &= ~(TIM_CCER_CC1P | TIM_CCER_CC2P);       
            TIM2->SMCR |= TIM_SMCR_SMS_0 | TIM_SMCR_SMS_1;       
            TIM2->CR1 |= TIM_CR1_CEN;                             
            break;

        case TIMER_3:

            RCC->APB1ENR |= RCC_APB1ENR_TIM3EN; 

            TIM3->ARR = 0xFFFF;

            TIM3->CCMR1 |= (TIM_CCMR1_CC1S_0 | TIM_CCMR1_CC2S_0); 
            TIM3->CCER &= ~(TIM_CCER_CC1P | TIM_CCER_CC2P);      
            TIM3->SMCR |= TIM_SMCR_SMS_0 | TIM_SMCR_SMS_1;      
            TIM3->CR1 |= TIM_CR1_CEN;
            break;

        case TIMER_4:

            RCC->APB1ENR |= RCC_APB1ENR_TIM4EN; 

            TIM4->ARR = 0xFFFF;

            TIM4->CCMR1 |= (TIM_CCMR1_CC1S_0 | TIM_CCMR1_CC2S_0);
            TIM4->CCER &= ~(TIM_CCER_CC1P | TIM_CCER_CC2P);      
            TIM4->SMCR |= TIM_SMCR_SMS_0 | TIM_SMCR_SMS_1; 
            TIM4->CR1 |= TIM_CR1_CEN;
            break;

        default:
            break;
    }
}

void Timer_Encoder_F1::update_counts()
{
    switch (timer_index)
    {
        case TIMER_1:   

            encodercount += (int16_t)TIM1->CNT; // Storing counts
            TIM1->CNT = 0;                      //resetting the timer to prevent the overflow
            break;

        case TIMER_2: 

            encodercount += (int16_t)TIM2->CNT;
            TIM2->CNT = 0;
            break;

        case TIMER_3:   

            encodercount += (int16_t)TIM3->CNT;
            TIM3->CNT = 0;
            break;

        case TIMER_4:   
                            
            encodercount += (int16_t)TIM4->CNT;
            TIM4->CNT = 0;
            break;
        
        default:
            break;
    }
}