#ifndef INTEGRATION_CONGIG_H_
#define INTEGRATION_CONFIG_H_

#include <ros.h>
#include "Encoder.h"
#include "Interrupt.h"
#include "PIDController.h"
#include "L298.h"
#include "cytron.h"
#include "Rabbit_config.h"
#include <std_msgs/String.h>
#include <std_msgs/Float32.h>
#include <std_msgs/Float32MultiArray.h>
#include <std_msgs/Int32MultiArray.h>
#include <Timer_Encoder_F1.h>
#include <Timer_Encoder.h>
#define SAMPLE_TIME_MS  10
#define DEADZONE        0.20

// ISR for Encoder 1
//void handleEncoder1InterruptA();
//void handleEncoder1InterruptB();

// ISR for Encoder 2
//void handleEncoder2InterruptA();
//void handleEncoder2InterruptB();

// ISR for Encoder 3
//void handleEncoder3InterruptA();
//void handleEncoder3InterruptB();

// ISR for Encoder 4
//void handleEncoder4InterruptA();
//void handleEncoder4InterruptB();

void handleSetpoint(const std_msgs::Float32MultiArray &msg);

// void handleSetpoint(const std_msgs::Float32 &msg);
void handlePIDParameters(const std_msgs::Float32MultiArray& msg);

ros::NodeHandle nh;
std_msgs::Float32MultiArray motorSpeedMessage;
std_msgs::Int32MultiArray encoderCountsMessage;
std_msgs::Float32MultiArray pidOutputMessage;
std_msgs::Float32MultiArray pidGraphMessage;
ros::Publisher motorSpeedPublisher("speed_feedback", &motorSpeedMessage);
ros::Publisher encoderCountsPublisher("counts_feedback", &encoderCountsMessage);
ros::Publisher pidOutputPublisher("pid_output", &pidOutputMessage);
ros::Publisher pidGraphPublisher("pid_graph", &pidGraphMessage);
ros::Subscriber<std_msgs::Float32MultiArray> setpointSubscriber("setpoint", handleSetpoint);
ros::Subscriber<std_msgs::Float32MultiArray> pidParamSubscriber("setParam", handlePIDParameters);

// Arrays for speed, setpoints, pid output and encoder counts
// float setpoints[4] ={0,0,0,0};
float setpoints[4];
float motorSpeeds[4];
long encoderCounts[4];
float pidOutputs[4];
float pidGraph[5];
unsigned long currentTimeMs;
unsigned long previousTimeMs = 0;
float deltaTime;

// Interrupt and Encoder Objects
//Interrupt encoder1Interrupt(ENCODER1_PIN_A, ENCODER1_PIN_B, handleEncoder1InterruptA, handleEncoder1InterruptB);
//Interrupt encoder2Interrupt(ENCODER2_PIN_A, ENCODER2_PIN_B, handleEncoder2InterruptA, handleEncoder2InterruptB);
//Interrupt encoder3Interrupt(ENCODER3_PIN_A, ENCODER3_PIN_B, handleEncoder3InterruptA, handleEncoder3InterruptB);
//Interrupt encoder4Interrupt(ENCODER4_PIN_A, ENCODER4_PIN_B, handleEncoder4InterruptA, handleEncoder4InterruptB);

Timer_Encoder_F1 encoders[] = {
  {ENCODER_RESOLUTION, MOTOR0_TIMER},
  {ENCODER_RESOLUTION, MOTOR1_TIMER},
  {ENCODER_RESOLUTION, MOTOR2_TIMER},
  {ENCODER_RESOLUTION, MOTOR3_TIMER}
};


// PID Controller Objects
PID motor1PID(KP1_INITIAL, KI1_INITIAL, KD1_INITIAL, SAMPLE_TIME_MS, DEADZONE, &nh);
PID motor2PID(KP2_INITIAL, KI2_INITIAL, KD2_INITIAL, SAMPLE_TIME_MS, DEADZONE, &nh);
PID motor3PID(KP3_INITIAL, KI3_INITIAL, KD3_INITIAL, SAMPLE_TIME_MS, DEADZONE, &nh);
PID motor4PID(KP4_INITIAL, KI4_INITIAL, KD4_INITIAL, SAMPLE_TIME_MS, DEADZONE, &nh);

// Motor Driver Objects
//L298 motorDriver1(MOTOR1_ENABLE_PIN, MOTOR1_INPUT1_PIN, MOTOR1_INPUT2_PIN);
//L298 motorDriver2(MOTOR2_ENABLE_PIN, MOTOR2_INPUT1_PIN, MOTOR2_INPUT2_PIN);
//L298 motorDriver3(MOTOR3_ENABLE_PIN, MOTOR3_INPUT1_PIN, MOTOR3_INPUT2_PIN);
//L298 motorDriver4(MOTOR4_ENABLE_PIN, MOTOR4_INPUT1_PIN, MOTOR4_INPUT2_PIN);
cytron motorDriver1(MOTOR1_DIR_PIN,MOTOR1_PWM_PIN);
cytron motorDriver2(MOTOR2_DIR_PIN,MOTOR2_PWM_PIN);
cytron motorDriver3(MOTOR3_DIR_PIN,MOTOR3_PWM_PIN);
cytron motorDriver4(MOTOR4_DIR_PIN,MOTOR4_PWM_PIN);

#endif
