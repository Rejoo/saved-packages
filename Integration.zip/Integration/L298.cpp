#include "L298.h"

L298::L298(int en, int in1, int in2) : dcDriver(), enablePin(en), input1Pin(in1), input2Pin(in2) {
    pinMode(enablePin, OUTPUT);
    pinMode(input1Pin, OUTPUT);
    pinMode(input2Pin, OUTPUT);
}

void L298::controlMotor() const {
    if (this->direction == FORWARD) {
        digitalWrite(input1Pin, HIGH);
        digitalWrite(input2Pin, LOW);
        analogWrite(enablePin, this->speed);
    } else if (this->direction == REVERSE) {
        digitalWrite(input1Pin, LOW);
        digitalWrite(input2Pin, HIGH);
        analogWrite(enablePin, this->speed);
    } else {
        digitalWrite(input1Pin, LOW);
        digitalWrite(input2Pin, LOW);
        analogWrite(enablePin, 0);
    }
}