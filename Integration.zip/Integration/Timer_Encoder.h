#ifndef TIMER_ENCODER_H
#define TIMER_ENCODER_H

#include "Encoder.h"
#include "STM_Timer.h"

/**
 * @class Timer_Encoder
 * @brief class for encoder interfacing with stm32 timers
*/
class Timer_Encoder : public Encoder
{

    public:

    /**
     * @brief the constructor of the timer encoder class
     * @param resolution the resolution of the encoder
     * @param timer_index the timer for stm32 (ex:Timer_1)
    */
    Timer_Encoder(float resolution, stm_timer_t timer_index);

    /**
     * @brief method for updating counts of the encoder
    */
    void update_counts();

    /**
     * @brief method for encoder setup
    */
    void setup();

    private:
    stm_timer_t timer_index;    ///<the timer index (ex:Timer_1)


};

#endif
