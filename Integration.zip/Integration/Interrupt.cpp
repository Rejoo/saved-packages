#include "Interrupt.h"

/*Interrupt::Interrupt(uint8_t pinA, uint8_t pinB, void (*ISRA)(), void (*ISRB)())
    : Encoder(), pinA(pinA), pinB(pinB), isrA(ISRA), isrB(ISRB) {}

void Interrupt::Init(){
  pinMode(pinA, INPUT_PULLUP);
  pinMode(pinB, INPUT_PULLUP);

  attachInterrupt(digitalPinToInterrupt(pinA), isrA, CHANGE);
  attachInterrupt(digitalPinToInterrupt(pinB), isrB, CHANGE);
}

void Interrupt::handleInterruptA(){
  if (digitalRead(pinA) == digitalRead(pinB)){
    count--;
  }
  else{
    count++;
  }
}

void Interrupt::handleInterruptB(){
  if (digitalRead(pinA) != digitalRead(pinB)){
    count--; 
  }
  else{
    count++;
  }
}*/
