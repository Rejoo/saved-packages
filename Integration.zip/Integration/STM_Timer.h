#ifndef STM_TIMER_H
#define STM_TIMER_H

typedef enum{
    TIMER_1 = 1,
    TIMER_2,
    TIMER_3,
    TIMER_4,
    TIMER_5
}stm_timer_t;

#endif