#ifndef INTERRUPT_H
#define INTERRUPT_H

#include <Arduino.h>
#include "Encoder.h"

class Interrupt : public Encoder{
    public:
        Interrupt(uint8_t pinA, uint8_t pinB, void (*ISRA)(), void (*ISRB)());
        void Init();
        void handleInterruptA();
        void handleInterruptB();

    private:
        uint8_t pinA;
        uint8_t pinB;
        void (*isrA)();  // Pointer to ISR A
        void (*isrB)();  // Pointer to ISR B
};

#endif
