// Initial PID parameters
#define KP1_INITIAL      1350
#define KI1_INITIAL      1.349
#define KD1_INITIAL      0.55

#define KP2_INITIAL      1600
#define KI2_INITIAL      1.355
#define KD2_INITIAL      0.54

#define KP3_INITIAL      1500
#define KI3_INITIAL      1.552
#define KD3_INITIAL      0.55

#define KP4_INITIAL      1500
#define KI4_INITIAL      1.557
#define KD4_INITIAL      0.54

// Encoder Resolution
#define ENCODER_RESOLUTION 2050

// Encoder Pins for Motors
#define ENCODER1_PIN_A PA6
#define ENCODER1_PIN_B PA7
#define ENCODER2_PIN_A PA8
#define ENCODER2_PIN_B PA9
#define ENCODER3_PIN_A PA0
#define ENCODER3_PIN_B PA1
#define ENCODER4_PIN_A PB6
#define ENCODER4_PIN_B PB7

// Motor Control Pins
//#define MOTOR1_ENABLE_PIN  PB1
//#define MOTOR1_INPUT1_PIN  PB10
//#define MOTOR1_INPUT2_PIN  PB11

//#define MOTOR2_ENABLE_PIN  PA6
//#define MOTOR2_INPUT1_PIN  PB0
//#define MOTOR2_INPUT2_PIN  PA7
//
//#define MOTOR3_ENABLE_PIN  PA1
//#define MOTOR3_INPUT1_PIN  PA0
//#define MOTOR3_INPUT2_PIN  PA2
//
//#define MOTOR4_ENABLE_PIN  PA3
//#define MOTOR4_INPUT1_PIN  PA4
//<#define MOTOR4_INPUT2_PIN  PA5
//Motor Control Pins

#define MOTOR1_SPEED_PIN
#define MOTOR1_SPEED_PIN
