#define __STM32F1__
#include "Integration_config.h"
#include "Rabbit_config.h"
#include <Servo.h>
int setpoint = 0;
Servo ESC;

void setup() {
  ESC.attach(PA7); //pin 9
  // Initialize ROS node and publishers
  // encoders[0].setup();
  // encoders[1].setup();
  // encoders[2].setup();
  encoders[3].setup();
  nh.initNode();
  nh.advertise(motorSpeedPublisher);
  nh.advertise(encoderCountsPublisher);
  nh.advertise(pidOutputPublisher);
  nh.advertise(pidGraphPublisher);
  nh.subscribe(setpointSubscriber);
  nh.subscribe(pidParamSubscriber);
  analogWriteResolution(16);
  // Serial.begin(9600);

  // Set up length of arrays
  motorSpeedMessage.data_length = 4;
  encoderCountsMessage.data_length = 4;
  pidOutputMessage.data_length = 4;
  pidGraphMessage.data_length = 5;

  // Initialize Encoders
  
}

void loop() {
  currentTimeMs = millis();
  deltaTime = currentTimeMs - previousTimeMs ;

  if( deltaTime >= SAMPLE_TIME_MS){
nh.subscribe(setpointSubscriber);



    // motor1PID.setSetpoint(setpoints[0]);
    // motor2PID.setSetpoint(setpoints[1]);
    // motor3PID.setSetpoint(setpoints[2]);
    motor4PID.setSetpoint(setpoints[3]);
    
    // Update counts data
    // encoders[0].update_counts();
    // encoders[1].update_counts();
    // encoders[2].update_counts();
    encoders[3].update_counts();

    // Update speed data
    // motorSpeeds[0] =  encoders[0].calcspeed();
    // motorSpeeds[1] =  encoders[1].calcspeed();
    // motorSpeeds[2] =  encoders[2].calcspeed();
    motorSpeeds[3] = encoders[3].calcspeed();

    // update feedback from encoder
    // motor1PID.setFeedback(motorSpeeds[0]);
    // motor2PID.setFeedback(motorSpeeds[1]);
    // motor3PID.setFeedback(motorSpeeds[2]);
    motor4PID.setFeedback(motorSpeeds[3]);

    // Update pid data
    // pidOutputs[0] = motor1PID.compute();
    // pidOutputs[1] = motor2PID.compute();
    // pidOutputs[2] = motor3PID.compute();
    pidOutputs[3] = motor4PID.compute();

    int ESC_Value = map(static_cast<int>(pidOutputs[3]), 0, 500, 1500, 2000); 
    ESC.writeMicroseconds(ESC_Value);
    // char buffer[50];  
    // sprintf(buffer, "Mapped Value: %d", ESC_Value);  
    // nh.loginfo(buffer);

    // Update pwm from pid
    // motorDriver1.setSpeed(pidOutputs[0]);
    // motorDriver2.setSpeed(pidOutputs[1]);
    // motorDriver3.setSpeed(pidOutputs[2]);
    // motorDriver4.setSpeed(pidOutputs[3]);

    // controll the movement
    // motorDriver1.controlMotor();
    // motorDriver2.controlMotor();
    // motorDriver3.controlMotor();
    // motorDriver4.controlMotor();

    // pidGraph[0] = motorSpeeds[0];
    // pidGraph[1] = motorSpeeds[1];
    // pidGraph[2] = motorSpeeds[2];
    pidGraph[3] = motorSpeeds[3];
    pidGraph[4] = currentTimeMs;


    // encoderCounts[0] = encoders[0].encodercount;
    // encoderCounts[1] = encoders[1].encodercount;
    // encoderCounts[2] = encoders[2].encodercount;
    encoderCounts[3] = encoders[3].encodercount;
    float pidOutputs[] = {0, 0, 0, static_cast<float>(ESC_Value)};
    encoderCountsMessage.data = encoderCounts;
    motorSpeedMessage.data = motorSpeeds;
    pidOutputMessage.data = pidOutputs;
    pidGraphMessage.data = pidGraph;
    // Publish both messages
    motorSpeedPublisher.publish(&motorSpeedMessage);
    encoderCountsPublisher.publish(&encoderCountsMessage);
    pidOutputPublisher.publish(&pidOutputMessage);
    pidGraphPublisher.publish(&pidGraphMessage);
    previousTimeMs = currentTimeMs;

  }

 
  nh.spinOnce();
  delay(1);
}



void handleSetpoint(const std_msgs::Float32MultiArray &msg) {
        // give setpoints
        // motor1PID.setSetpoint(msg.data[0]);
        // motor2PID.setSetpoint(msg.data[1]);
        // motor3PID.setSetpoint(msg.data[2]);
        // motor4PID.setSetpoint(msg.data[3]);
        float data[4] = {0,0,0,0};
        data[3] = msg.data[3];
        // setpoints[0] = msg.data[0];
        // setpoints[1] = msg.data[1];
        // setpoints[2] = msg.data[2];
        setpoints[3] = data[3];
        // setpoint = msg.data;
        // nh.loginfo(("setpoint: " + String(setpoints[3])).c_str());
        // // nh.loginfo(("setpoint: " + String(setpoint,9 )).c_str());
        // nh.loginfo(("condition setpoint: " + String((setpoint  == 0.0))).c_str());

        
}

// Callback function to update PID parameters from ROS topic
void handlePIDParameters(const std_msgs::Float32MultiArray &msg) {
      // Update PID parameters
      motor1PID.setParameters(msg.data[0], msg.data[1], msg.data[2]);
      motor2PID.setParameters(msg.data[3], msg.data[4], msg.data[5]);
      motor3PID.setParameters(msg.data[6], msg.data[7], msg.data[8]);
      motor4PID.setParameters(msg.data[9], msg.data[10], msg.data[11]);

}


