#include <cmath>
#include <cstdlib>
#include "PIDController.h"
#include <Arduino.h>  // Include for millis() function in Arduino

#define zero 0

// PID class constructor
PID::PID( float kp, float ki, float kd, float deltaTime , float deadzone, ros::NodeHandle* nodeHandle)
  : kp(kp), ki(ki), kd(kd), deltaTime(deltaTime), previousError(0), integral(0), error(0), deadzone(deadzone), nh(nodeHandle) {}

void PID::setSetpoint(float desiredSetpoint) {
  setpoint = desiredSetpoint;
}

void PID::setFeedback(float measuredFeedback) {
  feedback = measuredFeedback;
}

void PID::setParameters(float newKp, float newKi, float newKd) {
  kp = newKp;
  ki = newKi;
  kd = newKd;
}

float PID::compute() {
  // nh->loginfo(("setpoint: " + String(setpoint)).c_str());
  // nh->loginfo(("condition setpoint: " + String((setpoint == 0.0))).c_str());
  // nh->loginfo(("condition error: " + String((abs(error) <= abs(deadzone)))).c_str());
  error = setpoint - feedback;
  // nh->loginfo(("Error value :" + String(error)).c_str());
 if (abs(error) > abs(deadzone)) {
    integral += error * deltaTime;
    derivative = (error - previousError) / deltaTime;
    // anti windup
    if (integral > maxIntegralError) {
      integral = maxIntegralError;
      output = (kp * error) + (ki * integral) + (kd * derivative);
    }else {
      output = (kp * error) + (ki * integral) + (kd * derivative);
    }
    // nh->loginfo(("Error: 000" + String(error)).c_str());
  }

  else if((abs(error) <= abs(deadzone))){
    if (setpoint == 0.0){
    output = 0;
    integral = 0;
    // nh->loginfo(("Error: " + String(error)).c_str());
  }}
    nh->loginfo(("integral value :" + String(integral)).c_str());

  // nh->loginfo(("Error: " + String(error)).c_str());
  // nh->loginfo(("setpoint: " + String(setpoint)).c_str());
  // nh->loginfo(("deadzone: " + String(deadzone)).c_str());

  previousError = error;

  if (abs(output) > abs(maxOutput)){
    output = maxOutput;
  }
//   if (fabs(setpoint) < 1e-6) {
//     nh->loginfo("Setpoint is effectively zero.");
// } else {
//     nh->loginfo("Setpoint is NOT exactly zero.");
// }
  // nh->loginfo(("Error: " + String(error)).c_str());
  // nh->loginfo(("Integral: " + String(integral)).c_str());
  // nh->loginfo(("Derivative: " + String((error - previousError) / deltaTime)).c_str());
  // nh->loginfo(("Output: " + String(output)).c_str());
  // nh->loginfo(("kp: " + String(kp)).c_str());
  // nh->loginfo(("kd: " + String(kd)).c_str());
  // nh->loginfo(("ki: " + String(ki)).c_str());
  return output;
}

// // pid_ros class constructor
// pid_ros::pid_ros(float kp, float ki, float kd, float deltaTime , ros::NodeHandle* nh )
//     : PID(kp, ki, kd, deltaTime,deadzone),
//     pid_output_pub("pid_output", &pid_output_msg),
//     pid_param_sub("pid_parameters", &pid_ros::pidParamCallback,this){
//     this-> nh = nh ;
//     this->nh->advertise(pid_output_pub);
//     this->nh->subscribe(pid_param_sub);
// }

// // Static callback to update PID parameters
// void pid_ros::pidParamCallback(const std_msgs::Float32MultiArray &msg) {

//   setParameters(msg.data[0], msg.data[1], msg.data[2]);
// }

// // Publish the PID output
// void pid_ros::publishOutput() {
//     pid_output_msg.data = compute();
//     pid_output_pub.publish(&pid_output_msg);
// }