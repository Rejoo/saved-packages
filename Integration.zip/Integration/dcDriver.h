#ifndef DCDRIVER_H
#define DCDRIVER_H

#include <Arduino.h>

#define MAX_PWM  65536
#define MIN_PWM -65536

class dcDriver {
protected:
    enum Direction {
        STOP = 0,
        FORWARD = 1,
        REVERSE = -1
    };

    int speed;
    Direction direction;

public:
    dcDriver();  
    void setSpeed(float speedVal);
    float getSpeed() const;
    Direction getDirection() const;

    virtual void controlMotor() const = 0;
};

#endif