#ifndef cytron_H
#define cytron_H

#include "dcDriver.h"

class cytron : public dcDriver {
private:
    long DIR, PWM;

public:
    cytron(long DIR , long PWM);
    void controlMotor() const override;
};
#endif