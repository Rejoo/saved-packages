#!/bin/bash

#check which one is correct
# may be absoulte
# /home/rejo/catkin_ws/src/bringup/service/sh
# /home/rejo/catkin_ws/src/bringup/service/srv/
# or relative to bringup 
#  sh/
#  srv/

#roscore
sudo mkdir /etc/ros #uncomment if not exist
sudo cp sh/roscore.sh /etc/ros/env.sh
sudo cp service/srv/roscore.service /etc/systemd/system/roscore.service

#dead_reckoning
sudo cp sh/dead_reckoning.sh /usr/sbin/dead_reckoning_auto_launch 
sudo cp srv/dead_reckoning.service /etc/systemd/system/dead_reckoning.service
sudo chmod +x /usr/sbin/dead_reckoning_auto_launch

#stm
sudo cp sh/stm.sh /usr/sbin/stm_auto_launch 
sudo cp srv/stm.service /etc/systemd/system/stm.service
sudo chmod +x /usr/sbin/stm_auto_launch

#liDar
sudo cp sh/LiDar.sh /usr/sbin/LiDar_auto_launch 
sudo cp srv/LiDar.service e/tc/systemd/system/LiDar.service
sudo chmod +x /usr/sbin/LiDar_auto_launch

#imu
sudo cp sh/imu.sh /usr/sbin/imu_auto_launch 
sudo cp srv/imu.service /etc/systemd/system/imu.service
sudo chmod +x /usr/sbin/imu_auto_launch

#amcl
sudo cp sh/amcl.sh /usr/sbin/amcl_auto_launch 
sudo cp srv/amcl.service /etc/systemd/system/amcl.service
sudo chmod +x /usr/sbin/amcl_auto_launch

sudo systemctl daemon-reload

#enable on boot
# sudo systemctl enable roscore.service
# sudo systemctl enable dead_reckoning.service
sudo systemctl enable stm.service

#start
sudo systemctl start roscore.service
sudo systemctl start dead_reckoning.service
sudo systemctl start stm.service
sudo systemctl start LiDar.service
sudo systemctl start imu.service
sudo systemctl start amcl.service
