#!/bin/bash
source /home/rejo/catkin_ws/devel/setup.bash
source /etc/ros/env.sh

export ROS_HOME=$(echo ~rejo)/.ros

roslaunch rplidar_ros rplidar_a1.launch --wait

# Operation Canceled
exit 125

