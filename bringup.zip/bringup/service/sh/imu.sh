#!/bin/bash
source /home/rejo/catkin_ws/devel/setup.bash
source /etc/ros/env.sh

export ROS_HOME=$(echo ~rejo)/.ros

roslaunch imu_bno imu.launch --wait

# Operation Canceled
exit 125