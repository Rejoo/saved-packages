#!/bin/bash
source /home/rejo/catkin_ws/devel/setup.bash
source /etc/ros/env.sh

export ROS_HOME=$(echo ~rejo)/.ros

roslaunch dead_reckoning stm.launch --wait

# Operation Canceled
exit 125

