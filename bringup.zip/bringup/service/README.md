# Step by Step toutorial 

## Edit the following files

### sh:

change : ```source /home/rejo/catkin_ws/devel/setup.bash``` to your absoulte location of /deve/setup.bash.

change : rejo in ```export ROS_HOME=$(echo ~rejo)/.ros``` to your user name.

### srv:

change : rejo in ```User=rejo``` to your user name.

### how to get your user name 
write in terminal ```whoami``` and you will get it.



Running the install.sh file will allocate the files to the correct locations with appropriate permissions. It will also enable the services so that they will run on boot, however it will not start them for your current working session.

change the absolute location
```
cd /home/rejo/catkin_ws/src/bringup/service/install_sh/
```
```
chmod +x install.sh
```
```
./install.sh
```

## any change you should 
```
sudo systemctl daemon-reload
```

## Optional: Enable other services if required on boot
```
sudo systemctl enable LiDar.service
sudo systemctl enable imu.service
sudo systemctl enable amcl.service
```

## start on current session
```
sudo systemctl start roscore.service
sudo systemctl start dead_reckoning.service
sudo systemctl start stm.service
sudo systemctl start LiDar.service
sudo systemctl start imu.service
sudo systemctl start amcl.service
```

## disable on boot 
```
sudo systemctl disable LiDar.service
sudo systemctl disable imu.service
sudo systemctl disable amcl.service
```
