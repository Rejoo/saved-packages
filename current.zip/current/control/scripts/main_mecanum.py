#!/usr/bin/env python3

import rospy
from geometry_msgs.msg import Twist
from std_msgs.msg import Float32MultiArray
from kinematics.Mecanum_kinematics import KinematicsMecanum


def main():
    """Main function for kinematics Mecanum ROS node."""
    rospy.init_node('kinematics_mecanum_node')  
    # l_x = 0.15  
    # l_y = 0.15  
    l_x = 0.215  
    l_y = 0.28 
    kinematics = KinematicsMecanum(l_x, l_y)

    # Initialize the publisher within the kinematics class
    kinematics.pub = rospy.Publisher('/wheel_velocities', Float32MultiArray, queue_size=10)

    def callback(msg):
        """Callback function to process incoming Twist messages."""
        v_x = msg.linear.x
        v_y = msg.linear.y
        w = msg.angular.z
                
        # Calculate wheel velocities using the kinematics class
        wheels_velocities = kinematics.wheel_velocities(v_x, v_y, w)
        
        # Create and publish the message
        wheels_velocities_msg = Float32MultiArray()
        wheels_velocities_msg.data = wheels_velocities.flatten()
        kinematics.pub.publish(wheels_velocities_msg)

    # Subscribe to the /cmd_vel topic for velocity commands
    rospy.Subscriber("/cmd_vel", Twist, callback)

    # Set the loop rate
    rate = rospy.Rate(20)
    while not rospy.is_shutdown():
        rate.sleep()

if __name__ == '__main__':
    main()
